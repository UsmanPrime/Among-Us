
#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

class User {
protected:
    string username;
    string password;
    string role;

public:
    User(string uname = "", string pass = "", string r = "") 
        : username(uname), password(pass), role(r) {}

    virtual bool login(const string& uname, const string& pass);
    string getRole() const { return role; }
    string getUsername() const { return username; }
};

#endif // USER_H
