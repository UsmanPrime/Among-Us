#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include"Project.h"


void employeeLogin();
void employeeLoginmenu();
// Function Prototypes
void employeeMenu(const char* username);
void viewInventory();
void addProduct();
void updateStock();
void generateReports();
void manageSupportRequests();
void loadEmployees();
void saveEmployees();
void login(); // Customer login function prototype
void LoadCatalog();
void saveCatalog();
void loadSupportRequests();
void saveSupportRequests();
void checkLowStockAlerts();
void recordSalesContribution(const char* username, double saleAmount);
void generateSalesReport();
//void submitFeedback();
void manageFeedback();
void loadFeedbacks();
void saveFeedbacks();
void viewFeedbackDetails(int index);

#endif // EMPLOYEE_H
