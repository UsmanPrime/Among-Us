#include "Admin.h"

using namespace std;

// Constants for limits
const int MAX_CUSTOMERS = 100;
const int MAX_CART_SIZE = 500;
const int MAX_USERS = 200;
const int MAX_USERNAME_LENGTH = 50;
const int MAX_PASSWORD_LENGTH = 50;
const int ROLE_ADMIN = 0;
const int ROLE_EMPLOYEE = 1;
const int ROLE_CUSTOMER = 2;
const int OTP_LENGTH = 6;
const char* OTP_FILE = "admin_otp.txt";
const int MAX_SALES_RECORDS = 1000;
const int MAX_DAYS = 365;
const int MAX_CATEGORIES = 10;
const int MAX_PRODUCTS = 100; 
const int MAX_ACTIVITY_LOGS = 1000;
const char* ACTIVITY_LOG_FILE = "ActivityLogs.txt";
const int MAX_ANNOUNCEMENTS = 50;
const int MAX_ANNOUNCEMENT_LENGTH = 200;
const int MAX_TITLE_LENGTH = 100;


// Activity Log Structures
char activityLogUsernames[MAX_ACTIVITY_LOGS][50];
char activityLogActions[MAX_ACTIVITY_LOGS][100];
long activityLogTimestamps[MAX_ACTIVITY_LOGS];
int activityLogCount = 0; 
char* announcementTitles[MAX_ANNOUNCEMENTS];
char* announcementMessages[MAX_ANNOUNCEMENTS];
long announcementTimestamps[MAX_ANNOUNCEMENTS];
int announcementTargetRoles[MAX_ANNOUNCEMENTS];
int announcementCount = 0;

// Global arrays 
char productnames[MAX_PRODUCTS][50];
int ProductIDs[MAX_PRODUCTS];
double productPrices[MAX_PRODUCTS];
int productstockQuantities[MAX_PRODUCTS];
char productCategories[MAX_PRODUCTS][50];
int productsoldQuantities[MAX_PRODUCTS] = {0};


char userUsernames[MAX_USERS][MAX_USERNAME_LENGTH];
char userPasswords[MAX_USERS][MAX_PASSWORD_LENGTH];
int userRoles[MAX_USERS];
bool userActiveStatus[MAX_USERS];
int userCount = 0;
int salesProductIDs[MAX_SALES_RECORDS];
double salesPrices[MAX_SALES_RECORDS];
int salesQuantities[MAX_SALES_RECORDS];
double salesRevenues[MAX_SALES_RECORDS];
long salesDates[MAX_SALES_RECORDS];
int salesRecordCount = 0;

char categoriesNames[MAX_CATEGORIES][50];
double categoriesRevenue[MAX_CATEGORIES] = {0};
int categoriesCount = 0;

int catalog_Size = 0;


void adminloginmenu() {
    Loadcatalog(); // Load the catalog from file
    loadSalesRecords();
    //generateSalesReports();

    char c;
    while (true) {
       cout << "\n\t\t\t====================================" << endl;
        cout << "\t\t\t          Welcome to SecureShop      " << endl;
        cout << "\t\t\t====================================" << endl;

        // Main Menu Options
        cout << "\n\t\t\t          MAIN MENU                  \n";
        cout << "\t\t\t------------------------------------" << endl;
        cout << "\t\t\t  1. Login                          " << endl;
        cout << "\t\t\t  2. Exit                           " << endl;
        cout << "\t\t\t------------------------------------" << endl;

        // Prompt for User Input
        cout << "\t\t\t   Enter your choice: ";
        cin >> c;

       switch (c) {
            case '1':
                cout << "\n\t\t\t  Redirecting to Admin Login...\n";
                adminlogin();
                break;

            case '2':
                cout << "\n\t\t\t  Saving Catalog...\n";
                Savecatalog();
                cout << "\t\t\t====================================" << endl;
                cout << "\t\t\t  Thank you for using SecureShop!    " << endl;
                cout << "\t\t\t====================================" << endl;
                exit(0);
                break;

            default:
                cout << "\n\t\t\t  Invalid choice. Please try again.\n";
                break;
        }
    }
}


// User Authentication
void adminlogin() {
    char username[50], password[50];
    cout << "\nUsername: ";
    cin >> username;
    cout << "Password: ";
    cin >> password;

    // Load users first
    loadUsers();

    // Find user and validate
    int index = findUserIndex(username);
    if (index != -1 && 
        strcmp(userPasswords[index], password) == 0 && 
        userRoles[index] == ROLE_ADMIN && 
        userActiveStatus[index]) {
        
        logActivity(username, "Successful Admin Login");
        // Generate and send OTP
        char otp[OTP_LENGTH + 1];
        generateOTP(otp);
        saveOTP(username, otp);
        
        // Prompt for OTP
        char enteredOTP[OTP_LENGTH + 1];
        cout << "\nA 6-digit OTP has been generated. Please enter the OTP: ";
        cin >> enteredOTP;
        
        // Verify OTP
        if (verifyOTP(enteredOTP)) {
            cout << "\nTwo-Factor Authentication Successful!\n";
            adminMenu();
            return;
        } else {
            logActivity(username, "Failed 2FA Authentication");
            cout << "\nInvalid OTP. Access Denied.\n";
            return;
        }
    }
    logActivity(username, "Failed Login Attempt");
    cout << "\nInvalid username or password.\n";
}

// Admin Panel
void adminMenu() {
    // Load users and logs before showing menu
    loadUsers();
    loadActivityLogs();

    while (true) {
       char choice;

        // Admin Panel Banner
        cout << "\n\t\t====================================" << endl;
        cout << "\t\t|           ADMIN PANEL            |" << endl;
        cout << "\t\t====================================" << endl;

        // Menu Options
        cout << "\t\t| 1. Add Product                   |\n";
        cout << "\t\t| 2. Display Products              |\n";
        cout << "\t\t| 3. Advanced Search               |\n";
        cout << "\t\t| 4. Generate Reports              |\n";
        cout << "\t\t| 5. User Management               |\n";
        cout << "\t\t| 6. Security Monitoring           |\n";
        cout << "\t\t| 7. Add Anouncement               |\n";      
        cout << "\t\t| 8. Logout                        |\n";
        cout << "\t\t====================================" << endl;

        // Prompt for User Input
        cout << "\t\tEnter your choice: ";
        cin >> choice;

        cout << "\n----------------------------------------\n";

        cout << endl;

        switch (choice) {
            case '1':
                cout << "Redirecting to Add Product...\n";
                AddProduct();
                break;
            case '2':
                cout << "Displaying all products...\n";
                displayProduct();
                break;
            case '3':
                cout << "Redirecting to Advanced Search...\n";
                advanceSearch();
                break;
            case '4':
                cout << "Generating Reports...\n";
                GenerateReports();
                break;
            case '5': 
                userManagementMenu();
                break;
            case '6':
                cout << "Monitoring Security Logs...\n";
                monitorSecurityThreats();
                displayActivityLogs();
                break;
            case '7':
                addAnnouncementMenu();
                break;

            case '8':
                cout << "\t\t=======================================" << endl;
                cout << "\t\t|        Logging Out...                |\n";
                cout << "\t\t|    Thank you for using Admin Panel!  |\n";
                cout << "\t\t=======================================" << endl;
                return;
            default:
                cout << "Invalid choice. Please try again.\n";
                cout << "\n----------------------------------------\n";
        }
    }
}

// Admin Functions
void AddProduct() {
    if (catalog_Size >= MAX_PRODUCTS) {
        cout << "\n====================================" << endl;
        cout << "         Catalog is Full!           " << endl;
        cout << "====================================" << endl;
        cout << "Cannot add more products.\n";
        return;
    }

    cout << "\n====================================" << endl;
    cout << "          Add New Product           " << endl;
    cout << "====================================" << endl;

    cout << "Enter product name: ";
    cin.ignore();
    cin.getline(productnames[catalog_Size], 50);

    cout << "Enter product ID: ";
    cin >> ProductIDs[catalog_Size];

    cout << "Enter price: ";
    cin >> productPrices[catalog_Size];

    cout << "Enter stock quantity: ";
    cin >> productstockQuantities[catalog_Size];

    cout << "Enter category: ";
    cin.ignore();
    cin.getline(productCategories[catalog_Size], 50);

    catalog_Size++;
    Savecatalog(); // Save the catalog immediately after adding a product

    cout << "\n------------------------------------" << endl;
    cout << "Product added and saved successfully!" << endl;
    cout << "------------------------------------" << endl;
}


void displayProduct() 
{
    // Check if catalog is empty
    if (catalog_Size == 0) {
        cout << "\n====================================" << endl;
        cout << "    No products available in the catalog." << endl;
        cout << "====================================\n";
        return;
    }

    // Display product header
    cout << "\n====================================" << endl;
    cout << "         Available Products         " << endl;
    cout << "====================================" << endl;
    
    // Display table headers with spacing
    cout << "ID         Name                         Price          Stock     Category" << endl;
    cout << "---------------------------------------------------------------------------" << endl;

    // Display all products in catalog
    for (int i = 0; i < catalog_Size; i++) 
    {
        cout << ProductIDs[i] << "        " << left << setw(20) << productnames[i] << "        " << right << setw(8) << fixed << setprecision(2) << 
        productPrices[i] << "     " << right << setw(5) << productstockQuantities[i] << "        " << left << setw(15) << productCategories[i] << endl;
    }
     

    cout << "--------------------------------------------------------------------------\n";
}


// [Previous code remains the same, adding the complete advancedSearch() and remaining functions]

void advanceSearch() {
    char category[50] = "";
    double minPrice = 0.0, maxPrice = 1e9;
    int availabilityOption = -1;

    cout << "\n====================================" << endl;
    cout << "       Advanced Product Search      " << endl;
    cout << "====================================" << endl;

    // Get search criteria
    cout << "Enter category (leave blank for any): ";
    cin.ignore();
    cin.getline(category, 50);
    cout << "Enter minimum price (default 0): ";
    cin >> minPrice;
    cout << "Enter maximum price (leave blank or 0 for no limit): ";
    cin >> maxPrice;

    // Availability options
    cout << "\nAvailability options:\n";
    cout << "1. In Stock\n2. Out of Stock\n3. Any\n";
    cout << "Enter choice: ";
    cin >> availabilityOption;

    cout << "\n====================================" << endl;
    cout << "            Search Results          " << endl;
    cout << "====================================" << endl;
    cout << "ID        Name                Price     Stock     Category" << endl;
    cout << "------------------------------------------------------------\n";

    bool found = false;
    for (int i = 0; i < catalog_Size; i++) {
        bool categoryMatch = (strlen(category) == 0 || strcmp(productCategories[i], category) == 0);
        bool priceMatch = (productPrices[i] >= minPrice && productPrices[i] <= maxPrice);
        bool stockMatch = true;

        // Check stock availability
        if (availabilityOption == 1) stockMatch = (productstockQuantities[i] > 0);
        else if (availabilityOption == 2) stockMatch = (productstockQuantities[i] == 0);

        // If all conditions match, display the product
        if (categoryMatch && priceMatch && stockMatch) {
            cout << ProductIDs[i] << "        "
                 << left << setw(20) << productnames[i] << "        "
                 << right << setw(8) << fixed << setprecision(2) << productPrices[i] << "     "
                 << right << setw(5) << productstockQuantities[i] << "        "
                 << left << setw(15) << productCategories[i] << endl;
            found = true;
        }
    }

    // If no matching products are found
    if (!found) cout << "No products match the search criteria.\n";

    cout << "------------------------------------------------------------\n";
}

bool addUser(const char* username, const char* password, int role) {
    // Check if username already exists
     for (int i = 0; i < userCount; i++) {
        if (strcmp(userUsernames[i], username) == 0) {
            cout << "Username already exists!\n";
            return false;
        }
    }

    // Check if we've reached max users
    if (userCount >= MAX_USERS) {
        cout << "Maximum number of users reached!\n";
        return false;
    }

    // Add new user
    strncpy(userUsernames[userCount], username, MAX_USERNAME_LENGTH - 1);
    strncpy(userPasswords[userCount], password, MAX_PASSWORD_LENGTH - 1);
    userRoles[userCount] = role;
    userActiveStatus[userCount] = true;

    userCount++;
    saveUsers(); // Immediately save to persistent storage

    cout << "User added successfully!\n";
    return true;
}

void addUser() {
    char username[50], password[50];
    int role;

    cout << "Enter username: ";
    cin >> username;

    cout << "Enter password: ";
    cin >> password;

    cout << "Select role:\n";
    cout << "0. Admin\n";
    cout << "1. Employee\n";
    cout << "2. Customer\n";
    cout << "Enter role number: ";
    cin >> role;

    // Validate role input
    if (role < ROLE_ADMIN || role > ROLE_CUSTOMER) {
        cout << "Invalid role. Defaulting to Customer.\n";
        role = ROLE_CUSTOMER;
    }

    // Call existing addUser function with input
    addUser(username, password, role);
}




// Find User Index
int findUserIndex(const char* username) {
    for (int i = 0; i < userCount; i++) {
        if (strcmp(userUsernames[i], username) == 0) {
            return i;
        }
    }
    return -1;
}

bool modifyUserRole(const char* username, int newRole) {
    int index = findUserIndex(username);
    if (index != -1) {
        userRoles[index] = newRole;
        saveUsers(); // Save changes
        cout << "User role updated successfully!\n";
        return true;
    }
    cout << "User not found!\n";
    return false;
}

void initializeDefaultAdmin() {
    // Ensure a default admin account exists
    bool adminExists = false;
    for (int i = 0; i < userCount; i++) {
        if (userRoles[i] == ROLE_ADMIN && strcmp(userUsernames[i], "admin") == 0) {
            adminExists = true;
            break;
        }
    }

    if (!adminExists) {
        addUser("admin", "admin", ROLE_ADMIN);
    }
}

bool removeUser(const char* username) {
    int index = findUserIndex(username);
    if (index != -1) {
        // Remove by shifting array elements
        for (int j = index; j < userCount - 1; j++) {
            strcpy(userUsernames[j], userUsernames[j + 1]);
            strcpy(userPasswords[j], userPasswords[j + 1]);
            userRoles[j] = userRoles[j + 1];
            userActiveStatus[j] = userActiveStatus[j + 1];
        }
        userCount--;
        saveUsers(); // Save changes
        cout << "User removed successfully!\n";
        return true;
    }
    cout << "User not found!\n";
    return false;
}
void removeUser() {
    char username[50];

    cout << "Enter username to remove: ";
    cin >> username;

    // Call existing removeUser function
    removeUser(username);
}



void displayUsers() {
    cout << "\n====================================" << endl;
    cout << "           User Accounts            " << endl;
    cout << "====================================" << endl;
    cout << "Username         Role            Status" << endl;
    cout << "------------------------------------" << endl;

    for (int i = 0; i < userCount; i++) {
        // Directly use hardcoded role strings
        const char* roleString;
        switch(userRoles[i]) {
            case ROLE_ADMIN: roleString = "Admin"; break;
            case ROLE_EMPLOYEE: roleString = "Employee"; break;
            case ROLE_CUSTOMER: roleString = "Customer"; break;
            default: roleString = "Unknown"; break;
        }

        cout << left << setw(15) << userUsernames[i] 
             << setw(15) << roleString
             << (userActiveStatus[i] ? "Active" : "Inactive") 
             << endl;
    }
    cout << "------------------------------------" << endl;
}

void generateOTP(char* otp) {
    // Seed the random number generator
    srand(time(nullptr));
    
    for (int i = 0; i < OTP_LENGTH; i++) {
        // Generate random digit between 0-9
        otp[i] = '0' + (rand() % 10);
    }
    otp[OTP_LENGTH] = '\0'; // Null-terminate the string
}

// Function to save OTP to a file
void saveOTP(const char* username, const char* otp) {
    ofstream otpFile(OTP_FILE);
    if (otpFile.is_open()) {
        otpFile << username << '\n' << otp << '\n';
        otpFile.close();
    } else {
        cout << "Error: Unable to save OTP.\n";
    }
}

void logActivity(const char* username, const char* action) {
    if (activityLogCount >= MAX_ACTIVITY_LOGS) {
        // Rotate logs if maximum is reached
        for (int i = 0; i < MAX_ACTIVITY_LOGS - 1; i++) {
            strcpy(activityLogUsernames[i], activityLogUsernames[i+1]);
            strcpy(activityLogActions[i], activityLogActions[i+1]);
            activityLogTimestamps[i] = activityLogTimestamps[i+1];
        }
        activityLogCount--;
    }

    // Add new log entry
    strncpy(activityLogUsernames[activityLogCount], username, 49);
    strncpy(activityLogActions[activityLogCount], action, 99);
    activityLogTimestamps[activityLogCount] = time(nullptr);
    activityLogCount++;

    // Save to file
    saveActivityLogs();
}

void saveActivityLogs() {
    ofstream file(ACTIVITY_LOG_FILE);
    if (!file.is_open()) {
        cout << "Error: Unable to save activity logs!\n";
        return;
    }

    file << activityLogCount << '\n'; // Save number of logs
    for (int i = 0; i < activityLogCount; i++) {
        file << activityLogUsernames[i] << ' '
             << activityLogActions[i] << ' '
             << activityLogTimestamps[i] << '\n';
    }

    file.close();
}

void loadActivityLogs() {
    ifstream file(ACTIVITY_LOG_FILE);
    if (!file.is_open()) {
        cout << "No existing activity logs found.\n";
        return;
    }

    file >> activityLogCount;
    for (int i = 0; i < activityLogCount; i++) {
        file >> activityLogUsernames[i]
             >> activityLogActions[i]
             >> activityLogTimestamps[i];
    }

    file.close();
}

void timeNow(char* buffer, int bufferSize) {
    time_t currentTime = time(0);
    strftime(buffer, bufferSize, "%Y-%m-%d %H:%M:%S", localtime(&currentTime));
}
void displayActivityLogs() {
    cout << "\n====================================" << endl;
    cout << "         Activity Logs             " << endl;
    cout << "====================================" << endl;

    for (int i = 0; i < activityLogCount; i++) {
        // Convert timestamp to readable format
        char timeStr[100];
        strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", localtime(&activityLogTimestamps[i]));

        // Display log entry
        cout << "User: " << activityLogUsernames[i]
             << ", Action: " << activityLogActions[i]
             << ", Time: " << timeStr << endl;
    }

    // Display live time using the timeNow function
    char liveTimeStr[100];
    timeNow(liveTimeStr, sizeof(liveTimeStr));
    cout << "\nLive Time: " << liveTimeStr << endl;
}

void monitorSecurityThreats() {
    int failedLogins = 0;
    
    // Count recent failed login attempts
    for (int i = 0; i < activityLogCount; i++) {
        if (strstr(activityLogActions[i], "Failed Login") != nullptr) {
            failedLogins++;
        }
    }
    
    // Alert for multiple failed login attempts
    if (failedLogins > 5) {
        cout << "\n!!! SECURITY ALERT !!!" << endl;
        cout << "Multiple failed login attempts detected!" << endl;
        cout << "Total failed attempts: " << failedLogins << endl;
        cout << "Recommend reviewing security settings." << endl;
    }
}

// Function to verify OTP
bool verifyOTP(const char* enteredOTP) {
    ifstream otpFile(OTP_FILE);
    char savedUsername[50], savedOTP[OTP_LENGTH + 1];
    
    if (otpFile.is_open()) {
        otpFile.getline(savedUsername, sizeof(savedUsername));
        otpFile.getline(savedOTP, sizeof(savedOTP));
        otpFile.close();
        
        // Compare the entered OTP with saved OTP
        return strcmp(enteredOTP, savedOTP) == 0;
    }
    return false;
}


void saveUsers() {
    ofstream file("users.txt");
    if (!file.is_open()) {
        cout << "Error: Unable to save users!\n";
        return;
    }

    for (int i = 0; i < userCount; i++) {
        file << userUsernames[i] << ' '
             << userPasswords[i] << ' '
             << userRoles[i] << ' '
             << userActiveStatus[i] << '\n';
    }

    file.close();
}

// Load Users from File
void loadUsers() {
    ifstream file("users.txt");
    if (!file.is_open()) {
        cout << "No existing user accounts found.\n";
        initializeDefaultAdmin();
        return;
    }

    userCount = 0;
    while (file >> userUsernames[userCount] 
               >> userPasswords[userCount] 
               >> userRoles[userCount]
               >> userActiveStatus[userCount]) {
        userCount++;
    }

    file.close();
    
    // Ensure at least one admin exists
    initializeDefaultAdmin();
}

// User Management Menu for Admins
void userManagementMenu() {
    char choice;
    while (true) {
        cout << "\n====================================" << endl;
        cout << "        User Management Menu        " << endl;
        cout << "====================================" << endl;
        cout << "1. Add User" << endl;
        cout << "2. Remove User" << endl;
        cout << "3. Modify User Role" << endl;
        cout << "4. Display Users" << endl;
        cout << "5. Configure 2FA Settings" << endl; // New option
        cout << "6. Return to Admin Menu" << endl;
        
        cout << "------------------------------------" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        char username[50], password[50];
        int role;

        switch (choice) {
            case '1':
                cout << "Redirecting to Add User...\n";
                addUser();
                break;
            case '2':
                cout << "Removing User...\n";
                removeUser();
                break;
            case '3':
                cout << "Modifying User Role...\n";
                //userRoles();
                break;
            case '4':
                cout << "Displaying Users...\n";
                displayUsers();
                break;
           
            case '5': {
                cout << "2FA Configuration:\n";
                cout << "1. Enable 2FA for Admin\n";
                cout << "2. Disable 2FA for Admin\n";
                cout << "Enter choice: ";
                char twoFAChoice;
                cin >> twoFAChoice;

                // Placeholder for 2FA configuration logic
                switch (twoFAChoice) {
                    case '1':
                        cout << "2FA enabled for admin accounts.\n";
                        break;
                    case '2':
                        cout << "2FA disabled for admin accounts.\n";
                        break;
                    default:
                        cout << "Invalid choice.\n";
                }
                break;
            }
             case '6':
                cout << "Logging out. Goodbye!\n";
                return;

            default:
                cout << "Invalid choice. Please try again.\n";
        }
    }
}


void GenerateReports() {
        char choice;
    cout << "\n====================================" << endl;
    cout << "            Admin Reports            " << endl;
    cout << "====================================" << endl;
    cout << "1. Low Stock Products (Stock < 5)" << endl;
    cout << "2. High Selling Products (Sold > 0)" << endl;
    cout << "3. Products by Price Range" << endl;
    cout << "4. Sales Reports" << endl;
    cout << "------------------------------------" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
        case '1': { // Low Stock Products
            cout << "\n====================================" << endl;
            cout << "       Low Stock Products Report     " << endl;
            cout << "====================================" << endl;
            bool found = false;

            for (int i = 0; i < catalog_Size; i++) {
                if (productstockQuantities[i] < 5) {
                    cout << "ID: " << ProductIDs[i] << "\n"
                         << "Name: " << productnames[i] << "\n"
                         << "Stock: " << productstockQuantities[i] << "\n"
                         << "------------------------------------" << endl;
                    found = true;
                }
            }

            if (!found) {
                cout << "No products with low stock.\n";
            }
            break;
        }

        case '2': { // High Selling Products
            cout << "\n====================================" << endl;
            cout << "     High Selling Products Report    " << endl;
            cout << "====================================" << endl;
            bool found = false;

            for (int i = 0; i < catalog_Size; i++) {
                if (productsoldQuantities[i] > 0) {
                    cout << "ID: " << ProductIDs[i] << "\n"
                         << "Name: " << productnames[i] << "\n"
                         << "Sold: " << productsoldQuantities[i] << "\n"
                         << "------------------------------------" << endl;
                    found = true;
                }
            }

            if (!found) {
                cout << "No high-selling products yet.\n";
            }
            break;
        }

        case '3': { // Products by Price Range
            double minPrice, maxPrice;
            cout << "\n====================================" << endl;
            cout << "       Products by Price Range       " << endl;
            cout << "====================================" << endl;
            cout << "Enter minimum price: ";
            cin >> minPrice;
            cout << "Enter maximum price: ";
            cin >> maxPrice;

            cout << "\nProducts in Price Range [" << minPrice << ", " << maxPrice << "]:\n";
            cout << "------------------------------------" << endl;
            bool found = false;

            for (int i = 0; i < catalog_Size; i++) {
                if (productPrices[i] >= minPrice && productPrices[i] <= maxPrice) {
                    cout << "ID: " << ProductIDs[i] << "\n"
                         << "Name: " << productnames[i] << "\n"
                         << "Price: $" << productPrices[i] << "\n"
                         << "Stock: " << productstockQuantities[i] << "\n"
                         << "------------------------------------" << endl;
                    found = true;
                }
            }

            if (!found) {
                cout << "No products in the given price range.\n";
            }
            break;
        }
        case '4':{
            generateSalesReports();
        }

        default:
            cout << "\nInvalid choice. Returning to the menu...\n";
            break;
    }
}

void Loadcatalog() {
    ifstream file("catalog.txt");
    if (!file.is_open()) {
        cout << "No existing catalog found. Starting fresh.\n";
        return;
    }

    catalog_Size = 0; // Reset catalog size

    while (file >> ProductIDs[catalog_Size] 
                >> productPrices[catalog_Size] 
                >> productstockQuantities[catalog_Size] 
                >> productsoldQuantities[catalog_Size]) {
        file.ignore(); // Ignore the newline after the integers
        file.getline(productnames[catalog_Size], 50);
        file.getline(productCategories[catalog_Size], 50);
        catalog_Size++;
    }

    file.close();
    cout << "Catalog loaded successfully! " << catalog_Size << " products available.\n";
}

void cleanupAnnouncements() {
    for (int i = 0; i < announcementCount; i++) {
        delete[] announcementTitles[i];
        delete[] announcementMessages[i];
    }
}

bool addAnnouncement(const char* title, const char* message, int targetRole) {
    if (announcementCount >= MAX_ANNOUNCEMENTS) {
        cout << "Maximum number of announcements reached!\n";
        return false;
    }

    // Validate input lengths
    if (strlen(title) >= MAX_TITLE_LENGTH || strlen(message) >= MAX_ANNOUNCEMENT_LENGTH) {
        cout << "Title or message too long!\n";
        return false;
    }

    // Dynamically allocate memory for title and message
    announcementTitles[announcementCount] = new char[strlen(title) + 1];
    strcpy(announcementTitles[announcementCount], title);

    announcementMessages[announcementCount] = new char[strlen(message) + 1];
    strcpy(announcementMessages[announcementCount], message);

    // Set other announcement details
    announcementTimestamps[announcementCount] = time(nullptr);
    announcementTargetRoles[announcementCount] = targetRole;

    announcementCount++;
    saveAnnouncements();
    return true;
}

void loadAnnouncements() {
    // Clean up existing announcements first
    cleanupAnnouncements();
    announcementCount = 0;

    ifstream file("announcements.txt");
    if (!file.is_open()) {
        cout << "No existing announcements found.\n";
        return;
    }

    file >> announcementCount;
    file.ignore(); // Consume newline

    for (int i = 0; i < announcementCount; i++) {
        char tempTitle[MAX_TITLE_LENGTH];
        char tempMessage[MAX_ANNOUNCEMENT_LENGTH];

        file.getline(tempTitle, MAX_TITLE_LENGTH);
        file.getline(tempMessage, MAX_ANNOUNCEMENT_LENGTH);
        
        // Dynamically allocate memory
        announcementTitles[i] = new char[strlen(tempTitle) + 1];
        strcpy(announcementTitles[i], tempTitle);

        announcementMessages[i] = new char[strlen(tempMessage) + 1];
        strcpy(announcementMessages[i], tempMessage);

        file >> announcementTimestamps[i];
        file >> announcementTargetRoles[i];
        file.ignore(); // Consume newline
    }

    file.close();
}

void displayAnnouncements(int userRole) {
    cout << "\n====================================" << endl;
    cout << "          Announcements             " << endl;
    cout << "====================================" << endl;

    bool found = false;
    for (int i = 0; i < announcementCount; i++) {
        // Check if announcement is for this role or for all roles
        if (announcementTargetRoles[i] == userRole || 
            announcementTargetRoles[i] == 3) {
            
            // Convert timestamp to readable format
            char timeStr[100];
            time_t timestamp = announcementTimestamps[i];
            strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", 
                     localtime(&timestamp));

            cout << "Title: " << announcementTitles[i] << endl;
            cout << "Message: " << announcementMessages[i] << endl;
            cout << "Sent: " << timeStr << endl;
            cout << "------------------------------------" << endl;
            found = true;
        }
    }

    if (!found) {
        cout << "No announcements available for your role.\n";
    }
}

void addAnnouncementMenu() {
    char title[MAX_TITLE_LENGTH];
    char message[MAX_ANNOUNCEMENT_LENGTH];
    int targetRole;

    cout << "\n====================================" << endl;
    cout << "       Create Announcement           " << endl;
    cout << "====================================" << endl;

    cout << "Enter announcement title: ";
    cin.ignore();
    cin.getline(title, MAX_TITLE_LENGTH);

    cout << "Enter announcement message: ";
    cin.getline(message, MAX_ANNOUNCEMENT_LENGTH);

    cout << "Select target role:\n";
    cout << "0. Admin\n1. Employee\n2. Customer\n3. All Roles\n";
    cout << "Enter role number: ";
    cin >> targetRole;

    // Validate role input
    if (targetRole < 0 || targetRole > 3) {
        cout << "Invalid role. Defaulting to All Roles.\n";
        targetRole = 3;
    }

    // Add announcement
    if (addAnnouncement(title, message, targetRole)) {
        cout << "Announcement added successfully!\n";
    }
}

void saveAnnouncements() {
    ofstream file("announcements.txt");
    if (!file.is_open()) {
        cout << "Error: Unable to save announcements!\n";
        return;
    }

    file << announcementCount << '\n';
    for (int i = 0; i < announcementCount; i++) {
        file << announcementTitles[i] << '\n'
             << announcementMessages[i] << '\n'
             << announcementTimestamps[i] << '\n'
             << announcementTargetRoles[i] << '\n';
    }

    file.close();
}

// Record a Sale
void recordSale(int productID, int quantity) {
    // Validate product and stock
    int productIndex = -1;
    for (int i = 0; i < catalog_Size; i++) {
        if (ProductIDs[i] == productID) {
            productIndex = i;
            break;
        }
    }

    if (productIndex == -1 || quantity > productstockQuantities[productIndex]) {
        cout << "Invalid product or insufficient stock!\n";
        return;
    }

    // Check if sales records are full
    if (salesRecordCount >= MAX_SALES_RECORDS) {
        cout << "Maximum sales records reached!\n";
        return;
    }

    // Record sale
    salesProductIDs[salesRecordCount] = productID;
    salesPrices[salesRecordCount] = productPrices[productIndex];
    salesQuantities[salesRecordCount] = quantity;
    salesRevenues[salesRecordCount] = productPrices[productIndex] * quantity;
    salesDates[salesRecordCount] = time(nullptr);

    // Update product stock and sold quantities
    productstockQuantities[productIndex] -= quantity;
    productsoldQuantities[productIndex] += quantity;

    // Track category revenue
    int categoryIndex = findCategoryIndex(productCategories[productIndex]);
    if (categoryIndex != -1) {
        categoriesRevenue[categoryIndex] += salesRevenues[salesRecordCount];
    }

    salesRecordCount++;
    saveSalesRecords();
}

// Find or Add Category Index
int findCategoryIndex(const char* category) {
    // Try to find existing category
    for (int i = 0; i < categoriesCount; i++) {
        if (strcmp(categoriesNames[i], category) == 0) {
            return i;
        }
    }

    // Add new category if space available
    if (categoriesCount < MAX_CATEGORIES) {
        strcpy(categoriesNames[categoriesCount], category);
        categoriesCount++;
        return categoriesCount - 1;
    }

    return -1;
}

// Save Sales Records to File
void saveSalesRecords() {
    ofstream file("sales_records.txt");
    if (!file.is_open()) {
        cout << "Error: Unable to save sales records!\n";
        return;
    }

    // Save number of records first
    file << salesRecordCount << '\n';

    for (int i = 0; i < salesRecordCount; i++) {
        file << salesProductIDs[i] << ' '
             << salesPrices[i] << ' '
             << salesQuantities[i] << ' '
             << salesRevenues[i] << ' '
             << salesDates[i] << '\n';
    }

    file.close();
}

// Load Sales Records from File
void loadSalesRecords() {
    ifstream file("sales_records.txt");
    if (!file.is_open()) {
        cout << "No existing sales records found.\n";
        return;
    }

    // Read number of records
    file >> salesRecordCount;

    for (int i = 0; i < salesRecordCount; i++) {
        file >> salesProductIDs[i]
             >> salesPrices[i]
             >> salesQuantities[i]
             >> salesRevenues[i]
             >> salesDates[i];
    }

    file.close();
}

// Comprehensive Sales Reports Menu
void generateSalesReports() {
    char choice;
    do {
        cout << "\n====================================" << endl;
        cout << "         Advanced Sales Reports      " << endl;
        cout << "====================================" << endl;
        cout << "1. Daily Revenue Analysis" << endl;
        cout << "2. Top Selling Products" << endl;
        cout << "3. Monthly Performance Report" << endl;
        cout << "4. Sales Trends Analysis" << endl;
        cout << "5. Revenue by Product Category" << endl;
        cout << "6. Return to Main Menu" << endl;
        cout << "------------------------------------" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case '1':
                calculateDailyRevenue();
                break;
            case '2':
                findTopSellingProducts();
                break;
            case '3':
                generateMonthlyReport();
                break;
            case '4':
                analyzeSalesTrends();
                break;
            case '5':
                generateCategoryRevenueReport();
                break;
            case '6':
                return;  // Exit the reports menu
            default:
                cout << "Invalid choice. Please try again.\n";
        }
        
        // Pause to allow user to review the report
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    } while (true);
}

// Calculate Daily Revenue
void calculateDailyRevenue() {
    // Daily revenue array
    double dailyRevenue[MAX_DAYS] = {0};
    
    for (int i = 0; i < salesRecordCount; i++) {
        // Simple day calculation (assumes sales within same year)
        long dayKey = salesDates[i] / 86400; // Seconds per day
        dailyRevenue[dayKey] += salesRevenues[i];
    }

    cout << "\n====================================" << endl;
    cout << "         Daily Revenue Report        " << endl;
    cout << "====================================" << endl;

    for (int i = 0; i < MAX_DAYS; i++) {
        if (dailyRevenue[i] > 0) {
            cout << "Day: " << i 
                 << ", Total Revenue: $" << dailyRevenue[i] << endl;
        }
    }
}

// Find Top Selling Products
void findTopSellingProducts() {
    // Temporary arrays for sorting
    int topProductIDs[5] = {0};
    int topProductSales[5] = {0};

    // Find top 5 products
    for (int i = 0; i < catalog_Size; i++) {
        // Insert into sorted top 5 if applicable
        for (int j = 0; j < 5; j++) {
            if (productsoldQuantities[i] > topProductSales[j]) {
                // Shift existing values
                for (int k = 4; k > j; k--) {
                    topProductSales[k] = topProductSales[k-1];
                    topProductIDs[k] = topProductIDs[k-1];
                }
                
                // Insert new top product
                topProductSales[j] = productsoldQuantities[i];
                topProductIDs[j] = ProductIDs[i];
                break;
            }
        }
    }

    cout << "\n====================================" << endl;
    cout << "      Top Selling Products Report    " << endl;
    cout << "====================================" << endl;

    for (int i = 0; i < 5; i++) {
        if (topProductSales[i] > 0) {
            // Find product details
            for (int j = 0; j < catalog_Size; j++) {
                if (ProductIDs[j] == topProductIDs[i]) {
                    cout << "Rank " << (i+1) << ": " 
                         << productnames[j] 
                         << " (Sold: " << topProductSales[i] 
                         << ", Revenue: $" << topProductSales[i] * productPrices[j] 
                         << ")\n";
                    break;
                }
            }
        }
    }
}

// Monthly Performance Report
void generateMonthlyReport() {
    // Monthly revenue and sales arrays
    double monthlyRevenue[12] = {0};
    int monthlySales[12] = {0};

    for (int i = 0; i < salesRecordCount; i++) {
        // Basic month extraction (simplified)
        int month = (salesDates[i] / 2592000) % 12; // Approx seconds in a month
        monthlyRevenue[month] += salesRevenues[i];
        monthlySales[month] += salesQuantities[i];
    }

    cout << "\n====================================" << endl;
    cout << "     Monthly Performance Report      " << endl;
    cout << "====================================" << endl;

    for (int i = 0; i < 12; i++) {
        if (monthlyRevenue[i] > 0) {
            cout << "Month: " << (i+1) 
                 << ", Revenue: $" << monthlyRevenue[i] 
                 << ", Units Sold: " << monthlySales[i] 
                 << endl;
        }
    }
}

// Sales Trends Analysis
void analyzeSalesTrends() {
    double totalRevenue = 0;
    int totalUnitsSold = 0;

    for (int i = 0; i < salesRecordCount; i++) {
        totalRevenue += salesRevenues[i];
        totalUnitsSold += salesQuantities[i];
    }

    // Prevent division by zero
    double averageOrderValue = salesRecordCount > 0 ? 
        (totalRevenue / salesRecordCount) : 0;

    cout << "\n====================================" << endl;
    cout << "        Sales Trends Analysis        " << endl;
    cout << "====================================" << endl;
    cout << "Total Sales Records: " << salesRecordCount << endl;
    cout << "Total Revenue: $" << totalRevenue << endl;
    cout << "Total Units Sold: " << totalUnitsSold << endl;
    cout << "Average Order Value: $" << averageOrderValue << endl;
}

// Revenue by Product Category
void generateCategoryRevenueReport() {
    cout << "\n====================================" << endl;
    cout << "   Revenue by Product Category       " << endl;
    cout << "====================================" << endl;

    // Reset category revenues to ensure accuracy
    for (int i = 0; i < MAX_CATEGORIES; i++) {
        categoriesRevenue[i] = 0;
    }

    // Recalculate category revenues from sales records
    for (int i = 0; i < salesRecordCount; i++) {
        // Find the product's category
        for (int j = 0; j < catalog_Size; j++) {
            if (salesProductIDs[i] == ProductIDs[j]) {
                int categoryIndex = findCategoryIndex(productCategories[j]);
                if (categoryIndex != -1) {
                    categoriesRevenue[categoryIndex] += salesRevenues[i];
                }
                break;
            }
        }
    }

    // Display category revenues
    for (int i = 0; i < categoriesCount; i++) {
        if (categoriesRevenue[i] > 0) {
            cout << "Category: " << categoriesNames[i] 
                 << ", Total Revenue: $" << categoriesRevenue[i] << endl;
        }
    }
}


void Savecatalog() {
    ofstream file("catalog.txt");
    if (!file.is_open()) {
        cout << "Error: Unable to open catalog.txt for saving.\n";
        return;
    }

    for (int i = 0; i < catalog_Size; i++) {
        file << ProductIDs[i] << ' ' << productPrices[i] << ' '<< productstockQuantities[i] << ' ' 
             << productsoldQuantities[i] << '\n'
             << productnames[i] << '\n' 
             << productCategories[i] << '\n';
    }

    file.close();
    cout << "Catalog saved successfully!\n";
}
