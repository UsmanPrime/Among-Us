#ifndef ADMIN_H
#define ADMIN_H
#include"Project.h"


void adminlogin();
void adminloginmenu();
void adminMenu();
void AddProduct();
void displayProduct();
void advanceSearch();
void GenerateReports();
void Savecatalog();
void Loadcatalog();
void displayUsers();


void initializeDefaultAdmin();
bool addUser(const char* username, const char* password, int role);
bool removeUser(const char* username);
bool modifyUserRole(const char* username, int newRole);
//bool changeUserPassword(const char* username, const char* oldPassword, const char* newPassword);
int findUserIndex(const char* username);
void displayUsers();
void saveUsers();
void loadUsers();
void userManagementMenu();
void generateOTP(char* otp);
void saveOTP(const char* username, const char* otp);
bool verifyOTP(const char* enteredOTP);
void recordSale(int productID, int quantity);
void generateSalesReports();
void calculateDailyRevenue();
void findTopSellingProducts();
void generateMonthlyReport();
void analyzeSalesTrends();
int findCategoryIndex(const char* category);
void saveSalesRecords();
void generateCategoryRevenueReport();
void loadSalesRecords();
void logActivity(const char* username, const char* action);
void saveActivityLogs();
void loadActivityLogs();
void displayActivityLogs();
void monitorSecurityThreats();
void initializeDefaultAdmin();
bool addUser(const char* username, const char* password, int role);
bool removeUser(const char* username);
bool modifyUserRole(const char* username, int newRole);
void cleanupAnnouncements();
bool addAnnouncement(const char* title, const char* message, int targetRole);
void saveAnnouncements();
void loadAnnouncements();
void displayAnnouncements(int userRole);
void addAnnouncementMenu();



#endif // ADMIN_H
