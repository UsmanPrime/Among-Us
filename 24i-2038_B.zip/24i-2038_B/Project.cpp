#include"Project.h" 
using namespace std; 
 
int main() { 
    // Stylish banner 
    cout << "**************************************************\n";
    cout << "*                WELCOME TO SECURE SHOP         *\n";
    cout << "**************************************************\n\n"; 
 
    char choice; 
    do { 
        // Main menu design 
        cout << "+-----------------------------------------------+\n";
    cout << "|  [1] Home Page                               |\n";
    cout << "|  [2] Login                                   |\n";
    cout << "|  [3] About                                   |\n";
    cout << "|  [4] Contact                                 |\n";
    cout << "|  [5] Exit                                    |\n";
    cout << "+-----------------------------------------------+\n";
    cout << "Please select an option: ";
        cin >> choice;

        switch (choice) {
            case '1':
                cout << "\n--- HOME PAGE ---\n";
                cout << "Welcome to SecureShop! This platform offers a safe and\n";
                cout << "interactive way to explore cybersecurity in a simulated\n";
                cout << "e-commerce environment. Happy learning!\n\n";
                break;

            case '2': {
                char loginChoice;
                do {
                    cout << "+-----------------------------------------------+\n";
                    cout << "|               SECURE SHOP LOGIN               |\n";
                    cout << "+-----------------------------------------------+\n";
                    cout << "|  [1] Admin Login                             |\n";
                    cout << "|  [2] Employee Login                          |\n";
                    cout << "|  [3] Customer Login                          |\n";
                    cout << "|  [4] Announcements                           |\n";
                    cout << "|  [5] Go Back                                 |\n";
                    cout << "+-----------------------------------------------+\n";
                    cout << "Please select an option: ";
                    cin >> loginChoice; 
 
                    switch (loginChoice) { 
                        case '1': 
                            cout << "Admin login function called...\n"; 
                            adminloginmenu(); 
                            break; 
                        case '2': 
                            cout << "Employee login function called...\n"; 
                            employeeLoginmenu(); 
                            break; 
                        case '3': 
                            cout << "Customer login function called...\n"; 
                            customerloginmenu(); 
                            break; 
                        case '4': 
                            cout << "Display Announcements...\n"; 
                            displayAnnouncements(3); 
                            break; 
                        case '5': 
                            cout << "Returning to the main menu...\n"; 
                            break; 
                        default: 
                            cout << "Invalid choice! Please try again.\n"; 
                    } 
                } while (loginChoice != '4'); 
                break; 
            } 
 
            case '3': 
                cout << "\n--- ABOUT PAGE ---\n"; 
                cout << "SecureShop is a simulated e-commerce system designed\n"; 
                cout << "to teach cybersecurity concepts in a practical context.\n"; 
                cout << "It integrates file handling, role-based access control,\n"; 
                cout << "inventory management, and much more!\n\n"; 
                break; 
 
            case '4': 
                cout << "\n--- CONTACT PAGE ---\n"; 
                cout << "For inquiries, contact us at: +123-456-7890\n"; 
                cout << "Shake your phone to reveal more details.\n\n"; 
                break; 
 
            case '5': 
                cout << "\nExiting... Thank you for using SecureShop!\n\n"; 
                break;

            default:
                cout << "\nInvalid choice! Please try again.\n\n";
        }
    } while (choice != '5');

    return 0;
}