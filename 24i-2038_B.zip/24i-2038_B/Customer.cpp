#include"Customer.h"

using namespace std;

// Constants for limits
const int MAX_PRODUCTS = 100;
const int MAX_CUSTOMERS = 100;
const int MAX_CART_SIZE = 500;
const int MAX_WISHLIST_ITEMS = 50;
const int MAX_ORDER_HISTORY = 100;
const int MAX_SUPPORT_REQUESTS = 200;

// Global arrays 
char productNames[MAX_PRODUCTS][50];
int productIDs[MAX_PRODUCTS];
double ProductPrices[MAX_PRODUCTS];
int ProductStockQuantities[MAX_PRODUCTS];
char ProductCategories[MAX_PRODUCTS][50];
int ProductSoldQuantities[MAX_PRODUCTS] = {0};

char customerUsernames[MAX_CUSTOMERS][50];
char customerPasswords[MAX_CUSTOMERS][50];
int cartProductIDs[MAX_CUSTOMERS][MAX_CART_SIZE];
int cartQuantities[MAX_CUSTOMERS][MAX_CART_SIZE];
double cartTotals[MAX_CUSTOMERS] = {0.0};
int cartSizes[MAX_CUSTOMERS] = {0};

int catalogsize = 0;
int customerCount = 0;

int wishlistProductIDs[MAX_CUSTOMERS][MAX_WISHLIST_ITEMS];
int wishlistSizes[MAX_CUSTOMERS] = {0};

char orderHistoryProductNames[MAX_CUSTOMERS][MAX_ORDER_HISTORY][50];
int orderHistoryProductIDs[MAX_CUSTOMERS][MAX_ORDER_HISTORY];
double orderHistoryPrices[MAX_CUSTOMERS][MAX_ORDER_HISTORY];
char orderHistoryDates[MAX_CUSTOMERS][MAX_ORDER_HISTORY][20];
int orderHistoryCount[MAX_CUSTOMERS] = {0};

char SupportRequests[MAX_SUPPORT_REQUESTS][200];
int SupportRequestCount = 0;



void customerloginmenu() 
{
    loadOrderHistory();  // Load order history
    LoadSupportRequests();  // Load support requests
    loadCatalog();    // Load product catalog from file
    loadCustomers();  // Load customers from file
    loadWishlist();

    char c;
while (true) 
{
    // Welcome message with alignment
    cout << "\n\t\t\t====================================" << endl;
    cout << "\t\t\t          Welcome to SecureShop" << endl;
    cout << "\t\t\t====================================" << endl;

    // Menu options with better alignment
    cout << "\n\t1. Login" << endl;
    cout << "\t2. Register" << endl;
    cout << "\t3. Forgot Password" << endl;
    cout << "\t4. Exit" << endl;

    // Input prompt 
    cout << "\n\t------------------------------------" << endl;
    cout << "\t\tEnter your choice: ";
    cin >> c;

    // Switch case for handling different choices
    switch (c) 
    {
        case '1':
            cout << "\nRedirecting to Login...\n";
            customerlogin();
            break;
        case '2':
            cout << "\nRedirecting to Registration...\n";
            registration();
            break;
        case '3':
            cout << "\nRedirecting to Forgot Password...\n";
            forgot();
            break;
        case '4':
            cout << "\nSaving catalog and customer data...\n";
            save_Catalog();
            saveCustomers();
            saveWishlist();
            cout << "\nThank you for using SecureShop! Have a great day!\n";
            exit(0);
            break; 
        default:
            cout << "\nInvalid choice. Please try again.\n";
    }
}
}


// User Authentication8
void customerlogin() 
{
    char username[50], password[50];

    // Prompt for username and password 
    cout << "\n====================================" << endl;
    cout << "            Login to SecureShop     " << endl;
    cout << "====================================" << endl;

    cout << "\n\tUsername: ";
    cin >> username;
    cout << "\tPassword: ";
    cin >> password;

    // Check credentials and provide feedback
    for (int i = 0; i < customerCount; i++) 
    {
        if (strcmp(customerUsernames[i], username) == 0 && strcmp(customerPasswords[i], password) == 0) 
        {
            cout << "\n====================================" << endl;
            cout << "         Login Successful!          " << endl;
            cout << "====================================" << endl;
            customerMenu(username);
            return;
        }
    }

    // Invalid login message
    cout << "\n====================================" << endl;
    cout << "        Invalid username or password." << endl;
    cout << "====================================" << endl;
}


void registration() 
{
    if (customerCount >= MAX_CUSTOMERS) {
        cout << "\n====================================" << endl;
        cout << "   Registration Limit Reached!     " << endl;
        cout << "====================================" << endl;
        cout << "Cannot register more users.\n";
        return;
    }

    char username[50], password[50];

    // Prompt for username and password
    cout << "\n====================================" << endl;
    cout << "            Register New User       " << endl;
    cout << "====================================" << endl;

    cout << "\n\tEnter a username: ";
    cin >> username;
    cout << "\tEnter a password: ";
    cin >> password;

    // Check if username already exists
    for (int i = 0; i < customerCount; i++) 
    {
        if (strcmp(customerUsernames[i], username) == 0) {
            cout << "\n====================================" << endl;
            cout << "    Username already exists. Try a different one." << endl;
            cout << "====================================" << endl;
            return;
        }
    }

    // Register new user
    strcpy(customerUsernames[customerCount], username);
    strcpy(customerPasswords[customerCount], password);
    customerCount++;

    // Registration success message
    cout << "\n====================================" << endl;
    cout << "        Registration Successful!    " << endl;
    cout << "====================================" << endl;
}

void forgot() 
{
    char username[50];

    // Prompt for username with clear formatting
    cout << "\n====================================" << endl;
    cout << "        Forgot Password            " << endl;
    cout << "====================================" << endl;

    cout << "\n\tEnter your username: ";
    cin >> username;

    // Search for the username and display password if found
    for (int i = 0; i < customerCount; i++) 
    {
        if (strcmp(customerUsernames[i], username) == 0) {
            cout << "\n====================================" << endl;
            cout << "   Your password is: " << customerPasswords[i] << endl;
            cout << "====================================" << endl;
            return;
        }
    }

    // Error message for username not found
    cout << "\n====================================" << endl;
    cout << "   Username not found. Please try again." << endl;
    cout << "====================================" << endl;
}


// Customer Panel
void customerMenu(const char* username) 
{
    // Find the logged-in customer index
    int customerIndex = -1;
    for (int i = 0; i < customerCount; i++) {
        if (strcmp(customerUsernames[i], username) == 0) {
            customerIndex = i;
            break;
        }
    }

    // Check if customer exists
    if (customerIndex == -1) 
    {
        cout << "\n====================================" << endl;
        cout << "        Error: Customer Not Found   " << endl;
        cout << "====================================" << endl;
        return;
    }

    // Customer menu loop
    while (true) 
    {
        char choice;
        cout << "\n====================================" << endl;
        cout << "          Customer Panel            " << endl;
        cout << "====================================" << endl;

        // Display menu options with new features
        cout << "\t1. View All Products" << endl;
        cout << "\t2. Search Products" << endl;
        cout << "\t3. Manage Cart" << endl;
        cout << "\t4. Wishlist" << endl;
        cout << "\t5. Order History" << endl;
        cout << "\t6. Product Feedback" << endl;
        cout << "\t7. Support Request" << endl;
        cout << "\t8. Logout" << endl;

        cout << "\n\tEnter your choice: ";
        cin >> choice;

        // Handle menu choices
        switch (choice) {
            case '1':
                cout << "\nDisplaying all products...\n";
                displayProducts();
                break;
            case '2':
                cout << "\nInitiating product search...\n";
                advancedSearch();
                break;
            case '3':
                cout << "\nManaging your cart...\n";
                manageCart(customerIndex);
                break;
            case '4': {
                int wishlistChoice;
                cout << "\n1. Add to Wishlist\n2. View Wishlist\n3. Remove from Wishlist\n";
                cin >> wishlistChoice;
                switch(wishlistChoice) {
                    case 1: addToWishlist(customerIndex); break;
                    case 2: viewWishlist(customerIndex); break;
                    case 3: removeFromWishlist(customerIndex); break;
                }
                break;
            }
            case '5':
                viewOrderHistory(customerIndex);
                break;
            case '6':
                submitFeedback(customerIndex);
                break;
            case '7':
                submitSupportRequest(customerIndex);
                break;
            case '8':
                cout << "\nLogging out...\n";
                return;  // Logout
            default:
                cout << "\n====================================" << endl;
                cout << "     Invalid choice. Please try again." << endl;
                cout << "====================================" << endl;
        }
    }
}

void addItemToCart(int customerIndex) 
{
    int productID, quantity;

    // Prompt for product ID to add to the cart
    cout << "\n====================================" << endl;
    cout << "        Add Item to Cart           " << endl;
    cout << "====================================" << endl;
    cout << "\n\tEnter the Product ID to add to the cart: ";
    cin >> productID;

    // Search for the product in the catalog
    for (int i = 0; i < catalogsize; i++) 
    {
        if (productIDs[i] == productID) {
            // Check if the product is out of stock
            if (ProductStockQuantities[i] == 0) 
            {
                cout << "\n====================================" << endl;
                cout << "    This product is out of stock.   " << endl;
                cout << "====================================" << endl;
                return;
            }

            // Prompt for quantity to add to the cart
            cout << "\n\tEnter quantity: ";
            cin >> quantity;

            // Check if the requested quantity exceeds available stock
            if (quantity > ProductStockQuantities[i]) 
            {
                cout << "\n====================================" << endl;
                cout << "   Quantity exceeds available stock. Try again." << endl;
                cout << "====================================" << endl;
                return;
            }

            // Check if the item is already in the cart
            for (int j = 0; j < cartSizes[customerIndex]; j++) 
            {
                if (cartProductIDs[customerIndex][j] == productID) {
                    cartQuantities[customerIndex][j] += quantity;
                    ProductStockQuantities[i] -= quantity;
                    calculateCartTotal(customerIndex);
                    cout << "\n====================================" << endl;
                    cout << "   Item updated in cart successfully." << endl;
                    cout << "====================================" << endl;
                    return;
                }
            }

            // Add new item to cart
            cartProductIDs[customerIndex][cartSizes[customerIndex]] = productID;
            cartQuantities[customerIndex][cartSizes[customerIndex]] = quantity;
            cartSizes[customerIndex]++;
            ProductStockQuantities[i] -= quantity;
            calculateCartTotal(customerIndex);

            // Confirmation message
            cout << "\n====================================" << endl;
            cout << "   Item added to cart successfully." << endl;
            cout << "====================================" << endl;
            return;
        }
    }

    // If product not found
    cout << "\n====================================" << endl;
    cout << "       Product not found. Try again." << endl;
    cout << "====================================" << endl;
}


void removeItemFromCart(int customerIndex) 
{
    int productID;

    // Prompt to enter product ID to remove from the cart
    cout << "\n====================================" << endl;
    cout << "        Remove Item from Cart      " << endl;
    cout << "====================================" << endl;
    cout << "\n\tEnter the Product ID to remove from the cart: ";
    cin >> productID;

    // Search for the product in the customer's cart
    for (int i = 0; i < cartSizes[customerIndex]; i++) 
    {
        if (cartProductIDs[customerIndex][i] == productID)
         {
            // Restore stock to the catalog
            for (int j = 0; j < catalogsize; j++) 
            {
                if (productIDs[j] == productID) 
                {
                    ProductStockQuantities[j] += cartQuantities[customerIndex][i];
                }
            }

            // Remove item from the cart (shift items left)
            for (int j = i; j < cartSizes[customerIndex] - 1; j++) 
            {
                cartProductIDs[customerIndex][j] = cartProductIDs[customerIndex][j + 1];
                cartQuantities[customerIndex][j] = cartQuantities[customerIndex][j + 1];
            }

            // Decrease the cart size
            cartSizes[customerIndex]--;
            calculateCartTotal(customerIndex);

            // Confirmation message
            cout << "\n====================================" << endl;
            cout << "    Item removed from cart.        " << endl;
            cout << "====================================" << endl;
            return;
        }
    }

    // If product not found in the cart
    cout << "\n====================================" << endl;
    cout << "   Item not found in cart.         " << endl;
    cout << "====================================" << endl;
}


void calculateCartTotal(int customerIndex) 
{
    cartTotals[customerIndex] = 0.0;
    for (int i = 0; i < cartSizes[customerIndex]; i++) 
    {
        int productID = cartProductIDs[customerIndex][i];
        for (int j = 0; j < catalogsize; j++) 
        {
            if (productIDs[j] == productID) 
            {
                cartTotals[customerIndex] += ProductPrices[j] * cartQuantities[customerIndex][i];
                break;
            }
        }
    }
}

void viewCart(int customerIndex) 
{
    // Check if cart is empty
    if (cartSizes[customerIndex] == 0) 
    {
        cout << "\n====================================" << endl;
        cout << "            Your cart is empty.     " << endl;
        cout << "====================================" << endl;
        return;
    }

    // Display cart details
    cout << "\n====================================" << endl;
    cout << "              Your Cart             " << endl;
    cout << "====================================" << endl;
    cout << "ID        Name                Price     Quantity" << endl;
    cout << "-----------------------------------------------" << endl;

    // Loop through the cart and display product details
    for (int i = 0; i < cartSizes[customerIndex]; i++) 
    {
        int productID = cartProductIDs[customerIndex][i];
        for (int j = 0; j < catalogsize; j++) 
        {
            if (productIDs[j] == productID) 
            {
                // Display each product in the cart
                cout << productID << "        " 
                     << productNames[j] << "        " 
                     << "$" << ProductPrices[j] << "     " 
                     << cartQuantities[customerIndex][i] << endl;
                break;
            }
        }
    }

    // Display the cart total
    cout << "-----------------------------------------------" << endl;
    cout << "\nTotal Amount: $" << cartTotals[customerIndex] << endl;
    cout << "====================================" << endl;
}

void applyDiscount(int customerIndex) 
{
    // Check if cart is empty
    if (cartSizes[customerIndex] == 0) 
    {
        cout << "\n====================================" << endl;
        cout << "       Your cart is empty.         " << endl;
        cout << "   No discounts available.         " << endl;
        cout << "====================================" << endl;
        return;
    }

    double discount = 0.0;

    // Display available promotions
    cout << "\n====================================" << endl;
    cout << "           Available Promotions     " << endl;
    cout << "====================================" << endl;
    cout << "1. 10% off for orders above $100" << endl;
    cout << "2. $15 off for orders above $200" << endl;
    cout << "Enter choice (or 0 to skip): ";
    
    char choice;
    cin >> choice;

    // Apply selected discount
    switch (choice) 
    {
        case '1':
            if (cartTotals[customerIndex] > 100) 
            {
                discount = cartTotals[customerIndex] * 0.10;
                cartTotals[customerIndex] -= discount;
                cout << "Discount applied: -$" << discount << endl;
            } else 
            {
                cout << "Your cart total does not qualify for this discount.\n";
            }
            break;

        case '2':
            if (cartTotals[customerIndex] > 200) 
            {
                discount = 15.0;
                cartTotals[customerIndex] -= discount;
                cout << "Discount applied: -$" << discount << endl;
            } else 
            {
                cout << "Your cart total does not qualify for this discount.\n";
            }
            break;

        case '0':
            cout << "No discount applied.\n";
            break;

        default:
            cout << "Invalid choice. Please try again.\n";
    }

    // Show the updated total after discount
    cout << "\n====================================" << endl;
    cout << "   Updated Cart Total: $" << cartTotals[customerIndex] << endl;
    cout << "====================================" << endl;
}


void manageCart(int customerIndex) 
{
    while (true) {
        // Cart Management Header
        cout << "\n====================================" << endl;
        cout << "        --- Cart Management ---      " << endl;
        cout << "====================================" << endl;

        // Cart Management Options
        cout << "1. Add Item to Cart\n";
        cout << "2. Remove Item from Cart\n";
        cout << "3. View Cart\n";
        cout << "4. Apply Discount\n";
        cout << "5. Checkout\n";
        cout << "6. Back to Main Menu\n";
        cout << "------------------------------------" << endl;
        cout << "Enter your choice: ";

        char choice;
        cin >> choice;

        // Process user choice
        switch (choice) 
        {
            case '1':
                addItemToCart(customerIndex);
                break;

            case '2':
                removeItemFromCart(customerIndex);
                break;

            case '3':
                viewCart(customerIndex);
                break;

            case '4':
                applyDiscount(customerIndex);
                break;

            case '5': 
            {
            // Checkout
            cout << "\n====================================" << endl;
            cout << "     Checking out... Final total: $" << cartTotals[customerIndex] << endl;
            cout << "====================================" << endl;
            
            // Record order history before clearing the cart
            recordOrderHistory(customerIndex);
            
            // Reset cart after checkout
            cartSizes[customerIndex] = 0;  // Clear the cart
            cartTotals[customerIndex] = 0.0;
            return;
        }

            case '6':
                return;  // Go back to main menu

            default:
                cout << "\nInvalid choice. Please try again.\n";
        }
    }
}

void displayProducts() 
{
    // Check if catalog is empty
    if (catalogsize == 0) {
        cout << "\n====================================" << endl;
        cout << "    No products available in the catalog." << endl;
        cout << "====================================\n";
        return;
    }

    // Display product header
    cout << "\n====================================" << endl;
    cout << "         Available Products         " << endl;
    cout << "====================================" << endl;
    
    // Display table headers with spacing
    cout << "ID        Name                Price     Stock     Category" << endl;
    cout << "------------------------------------------------------------" << endl;

    // Display all products in catalog
    for (int i = 0; i < catalogsize; i++) 
    {
        cout << productIDs[i] << "        "
             << left << setw(20) << productNames[i] << "        " << right << setw(8) << fixed << setprecision(2) << ProductPrices[i] << "     "
             << right << setw(5) << ProductStockQuantities[i] << "        " << left << setw(15) << ProductCategories[i] << endl;
    }

    cout << "------------------------------------------------------------\n";
}


void advancedSearch() 
{
    // Dynamically allocate memory for category
    char* category = new char[50];
    category[0] = '\0'; // Initialize to an empty string

    double minPrice = 0.0, maxPrice = 1e9;
    int availabilityOption = -1;

    cout << "\n====================================" << endl;
    cout << "       Advanced Product Search      " << endl;
    cout << "====================================" << endl;

    // Get search criteria
    cout << "Enter category (leave blank for any): ";
    cin.ignore();
    cin.getline(category, 50);

    cout << "Enter minimum price (default 0): ";
    cin >> minPrice;

    cout << "Enter maximum price (leave blank or 0 for no limit): ";
    cin >> maxPrice;

    // Availability options
    cout << "\nAvailability options:\n";
    cout << "1. In Stock\n2. Out of Stock\n3. Any\n";
    cout << "Enter choice: ";
    cin >> availabilityOption;

    cout << "\n====================================" << endl;
    cout << "            Search Results          " << endl;
    cout << "====================================" << endl;
    cout << "ID        Name                Price     Stock     Category" << endl;
    cout << "------------------------------------------------------------\n";

    bool found = false;
    for (int i = 0; i < catalogsize; i++) 
    {
        bool categoryMatch = (strlen(category) == 0 || strcmp(ProductCategories[i], category) == 0);
        bool priceMatch = (ProductPrices[i] >= minPrice && ProductPrices[i] <= maxPrice);
        bool stockMatch = true;
        // Check stock availability
        if (availabilityOption == 1) 
            stockMatch = (ProductStockQuantities[i] > 0);
        else if (availabilityOption == 2) 
            stockMatch = (ProductStockQuantities[i] == 0);
        // If all conditions match, display the product
        if (categoryMatch && priceMatch && stockMatch) 
        {
            cout << productIDs[i] << "        "
                 << left << setw(20) << productNames[i] << "        " << right << setw(8) << fixed << setprecision(2) << ProductPrices[i] << "     "
                 << right << setw(5) << ProductStockQuantities[i] << "        " << left << setw(15) << ProductCategories[i] << endl;
            found = true;
        }
    }
    if (!found) 
    {
        cout << "No products match the search criteria.\n";
    }

    cout << "------------------------------------------------------------\n";
    delete[] category;
}

// Persistent Storage
void loadCatalog() 
{
    ifstream file("catalog.txt");
    if (file.is_open()) {
        while (catalogsize < MAX_PRODUCTS && 
               file >> productIDs[catalogsize] >> ProductPrices[catalogsize] >> ProductStockQuantities[catalogsize] >> ProductSoldQuantities[catalogsize]) 
            {
            file.ignore();
            file.getline(productNames[catalogsize], 50);
            file.getline(ProductCategories[catalogsize], 50);
            catalogsize++;
        }
        file.close();
    }
}
void submitSupportRequest(int customerIndex) 
{
    // Check if support request limit is reached
    if (SupportRequestCount >= MAX_SUPPORT_REQUESTS) 
    {
        cout << "\n====================================" << endl;
        cout << "   Support Request Limit Reached   " << endl;
        cout << "====================================" << endl;
        return;
    }

    // Declare support request message
    char supportMessage[200];

    // Prompt for support request
    cout << "\n====================================" << endl;
    cout << "        Submit Support Request      " << endl;
    cout << "====================================" << endl;
    
    cout << "\nPlease describe your support issue (max 200 characters): ";
    cin.ignore(); // Clear any previous input buffer
    cin.getline(supportMessage, 200);

    // If user didn't enter anything, cancel
    if (strlen(supportMessage) == 0) 
    {
        cout << "\nSupport request canceled.\n";
        return;
    }

    // Create a detailed support request with customer username
    char fullSupportRequest[250];
    snprintf(fullSupportRequest, sizeof(fullSupportRequest), 
             "Customer: %s - Request: %s", 
             customerUsernames[customerIndex], supportMessage);

    // Add support request to global array
    strcpy(SupportRequests[SupportRequestCount], fullSupportRequest);
    SupportRequestCount++;

    // Optionally save support requests immediately
    SaveSupportRequests();

    // Confirmation message
    cout << "\n====================================" << endl;
    cout << "    Support Request Submitted!      " << endl;
    cout << "====================================" << endl;
}

void save_Catalog()
 {
    ofstream file("catalog.txt");
    if (!file.is_open()) {
        cout << "Error: Unable to open catalog.txt for saving.\n";
        return;
    }
    for (int i = 0; i < catalogsize; i++) {
        file << productIDs[i] << ' ' << ProductPrices[i] << ' ' << ProductStockQuantities[i] << ' ' << ProductSoldQuantities[i] << '\n'
             << productNames[i] << '\n' << ProductCategories[i] << '\n';
    }
    saveOrderHistory();  // Save order history
    SaveSupportRequests();
    saveWishlist();
    //saveSupport;
    file.close();
}

void loadCustomers() 
{
    ifstream file("customers.txt");
    if (file.is_open()) 
    {
        while (customerCount < MAX_CUSTOMERS && 
               file >> customerUsernames[customerCount] >> customerPasswords[customerCount]) 
               
               {
            customerCount++;
        }
        file.close();
    }
}

void saveCustomers() 
{
    ofstream file("customers.txt");
    for (int i = 0; i < customerCount; i++) 
    {
        file << customerUsernames[i] << ' ' << customerPasswords[i] << '\n';
    }
    file.close();
}

void addToWishlist(int customerIndex) {
    int productID;

    // Check if wishlist is full
    if (wishlistSizes[customerIndex] >= MAX_WISHLIST_ITEMS) {
        cout << "\n====================================" << endl;
        cout << "   Wishlist is full. Remove an item first." << endl;
        cout << "====================================" << endl;
        return;
    }

    // Prompt for product ID
    cout << "\n====================================" << endl;
    cout << "        Add to Wishlist           " << endl;
    cout << "====================================" << endl;
    cout << "\n\tEnter Product ID to add to wishlist: ";
    cin >> productID;

    // Check if product exists in catalog
    for (int i = 0; i < catalogsize; i++) {
        if (productIDs[i] == productID) {
            // Check if already in wishlist
            for (int j = 0; j < wishlistSizes[customerIndex]; j++) {
                if (wishlistProductIDs[customerIndex][j] == productID) {
                    cout << "\n====================================" << endl;
                    cout << "   Product already in wishlist.   " << endl;
                    cout << "====================================" << endl;
                    return;
                }
            }

            // Add to wishlist
            wishlistProductIDs[customerIndex][wishlistSizes[customerIndex]] = productID;
            wishlistSizes[customerIndex]++;

            // Save wishlist using standard method
            saveWishlist();

            cout << "\n====================================" << endl;
            cout << "   Product added to wishlist.      " << endl;
            cout << "   Wishlist saved.                " << endl;
            cout << "====================================" << endl;
            return;
        }
    }

    // Product not found
    cout << "\n====================================" << endl;
    cout << "   Product not found in catalog.   " << endl;
    cout << "====================================" << endl;
}

// Implement View Wishlist
void viewWishlist(int customerIndex) 
{
    // Check if wishlist is empty
    if (wishlistSizes[customerIndex] == 0) 
    {
        cout << "\n====================================" << endl;
        cout << "        Your Wishlist is Empty      " << endl;
        cout << "====================================" << endl;
        return;
    }

    // Display wishlist header
    cout << "\n====================================" << endl;
    cout << "             Your Wishlist          " << endl;
    cout << "====================================" << endl;
    cout << "ID        Name                Price     Stock     Category" << endl;
    cout << "------------------------------------------------------------" << endl;

    // Iterate through wishlist and display details
    for (int i = 0; i < wishlistSizes[customerIndex]; i++) 
    {
        int productID = wishlistProductIDs[customerIndex][i];
        for (int j = 0; j < catalogsize; j++) 
        {
            if (productIDs[j] == productID) 
            {
                cout << productIDs[j] << "        " << left << setw(20) << productNames[j] << "        " << right << setw(8) << fixed << setprecision(2) << ProductPrices[j] << "     "
                     << right << setw(5) << ProductStockQuantities[j] << "        " << left << setw(15) << ProductCategories[j] << endl;
                break;
            }
        }
    }
    cout << "------------------------------------------------------------" << endl;
}

void loadWishlist() 
{
    ifstream wishlistFile("wishlist.txt");
    if (wishlistFile.is_open()) {
        int totalCustomers;
        wishlistFile >> totalCustomers;

        // Ensure we don't exceed MAX_CUSTOMERS
        totalCustomers = min(totalCustomers, customerCount);
        
        // Load wishlist for each customer
        for (int customer = 0; customer < totalCustomers; customer++) {
            int savedWishlistSize;
            wishlistFile >> savedWishlistSize;
            
            // Ensure we don't exceed MAX_WISHLIST_ITEMS
            savedWishlistSize = min(savedWishlistSize, MAX_WISHLIST_ITEMS);
            
            // Clear existing wishlist
            wishlistSizes[customer] = 0;
            
            // Read product IDs
            for (int i = 0; i < savedWishlistSize; i++) {
                wishlistFile >> wishlistProductIDs[customer][i];
            }
            
            // Update wishlist size
            wishlistSizes[customer] = savedWishlistSize;
        }
        
        wishlistFile.close();
    }
}


void saveWishlist() 
{
    ofstream file("wishlist.txt");
    if (!file.is_open()) {
        cout << "Error: Unable to open wishlist.txt for saving.\n";
        return;
    }

    // Write the total number of customers
    file << customerCount << '\n';

    // Save wishlist for each customer
    for (int customer = 0; customer < customerCount; customer++) 
    {
        // Write wishlist size for this customer
        file << wishlistSizes[customer] << '\n';
        
        // Write details for each wishlist entry
        for (int i = 0; i < wishlistSizes[customer]; i++) 
        {
            file << wishlistProductIDs[customer][i] << ' ';
        }
        file << '\n';  // End of customer's wishlist
    }
    file.close();
}


// Implement Remove from Wishlist
void removeFromWishlist(int customerIndex) 
{
    int productID;

    // Check if wishlist is empty
    if (wishlistSizes[customerIndex] == 0) 
    {
        cout << "\n====================================" << endl;
        cout << "        Your Wishlist is Empty      " << endl;
        cout << "====================================" << endl;
        return;
    }

    // Prompt for product ID to remove
    cout << "\n====================================" << endl;
    cout << "        Remove from Wishlist       " << endl;
    cout << "====================================" << endl;
    cout << "\n\tEnter Product ID to remove from wishlist: ";
    cin >> productID;

    // Find and remove the product
    for (int i = 0; i < wishlistSizes[customerIndex]; i++) 
    {
        if (wishlistProductIDs[customerIndex][i] == productID) {
            // Shift remaining items
            for (int j = i; j < wishlistSizes[customerIndex] - 1; j++) 
            {
                wishlistProductIDs[customerIndex][j] = wishlistProductIDs[customerIndex][j + 1];
            }
            wishlistSizes[customerIndex]--;

            cout << "\n====================================" << endl;
            cout << "   Product removed from wishlist.  " << endl;
            cout << "====================================" << endl;
            return;
        }
    }

    // Product not found in wishlist
    cout << "\n====================================" << endl;
    cout << "   Product not found in wishlist.   " << endl;
    cout << "====================================" << endl;
}

// Implement View Order History
void recordOrderHistory(int customerIndex) 
{
    // Get current date (for simplicity, we'll use a placeholder)
    char currentDate[20] = "2024-01-01";  //real time function add krna hai

    // Ensure we don't exceed maximum order history
    if (orderHistoryCount[customerIndex] >= MAX_ORDER_HISTORY) 
    {
        // Shift existing entries to make room for new one
        for (int i = 0; i < MAX_ORDER_HISTORY - 1; i++) 
        {
            strcpy(orderHistoryProductNames[customerIndex][i], 
                   orderHistoryProductNames[customerIndex][i+1]);
            orderHistoryProductIDs[customerIndex][i] = 
                orderHistoryProductIDs[customerIndex][i+1];
            orderHistoryPrices[customerIndex][i] = 
                orderHistoryPrices[customerIndex][i+1];
            strcpy(orderHistoryDates[customerIndex][i], 
                   orderHistoryDates[customerIndex][i+1]);
        }
        orderHistoryCount[customerIndex]--;
    }

    // Record each item in the cart to order history
    for (int i = 0; i < cartSizes[customerIndex]; i++) 
    {
        int productID = cartProductIDs[customerIndex][i];
        
        // Find product details in catalog
        for (int j = 0; j < catalogsize; j++) 
        {
            if (productIDs[j] == productID) 
            {
                // Copy product details to order history
                strcpy(orderHistoryProductNames[customerIndex][orderHistoryCount[customerIndex]], productNames[j]);
                orderHistoryProductIDs[customerIndex][orderHistoryCount[customerIndex]] = productID;
                orderHistoryPrices[customerIndex][orderHistoryCount[customerIndex]] = ProductPrices[j] * cartQuantities[customerIndex][i];
                strcpy(orderHistoryDates[customerIndex][orderHistoryCount[customerIndex]],  currentDate);
                
                orderHistoryCount[customerIndex]++;
                break;
            }
        }
    }
}

void viewOrderHistory(int customerIndex) 
{
    // Check if order history is empty
    if (orderHistoryCount[customerIndex] == 0) {
        cout << "\n====================================" << endl;
        cout << "        No Order History Found     " << endl;
        cout << "====================================" << endl;
        return;
    }

    // Display order history header
    cout << "\n====================================" << endl;
    cout << "           Order History            " << endl;
    cout << "====================================" << endl;
    cout << "Date        Product Name        Price" << endl;
    cout << "--------------------------------------------" << endl;

    // Iterate through order history
    for (int i = 0; i < orderHistoryCount[customerIndex]; i++) 
    {
        cout << orderHistoryDates[customerIndex][i] << "    " << left << setw(20) << orderHistoryProductNames[customerIndex][i] << "    "
             << right << fixed << setprecision(2) << orderHistoryPrices[customerIndex][i] << endl;
    }
    cout << "--------------------------------------------" << endl;
}

// Implement Submit Feedback
void submitFeedback(int customerIndex) 
{
    if (orderHistoryCount[customerIndex] == 0) {
        cout << "\n====================================" << endl;
        cout << "   No purchases to provide feedback on." << endl;
        cout << "====================================" << endl;
        return;
    }

    int productChoice;

    // Display recent purchases for feedback
    cout << "\n====================================" << endl;
    cout << "        Submit Product Feedback     " << endl;
    cout << "====================================" << endl;
    
    for (int i = 0; i < orderHistoryCount[customerIndex]; i++) 
    {
        cout << i + 1 << ". " << orderHistoryProductNames[customerIndex][i] << endl;
    }

    // Robust input handling
    while (true) {
        cout << "\nSelect a product to provide feedback (0 to cancel): ";
        
        // Clear any previous error states
        if (!(cin >> productChoice)) {
            cin.clear(); // Clear error flags
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
            cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        // Clear any remaining characters in the input buffer
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (productChoice == 0) {
            cout << "Feedback submission canceled.\n";
            return;
        }

        if (productChoice >= 1 && productChoice <= orderHistoryCount[customerIndex]) {
            break;
        }

        cout << "Invalid selection. Please try again.\n";
    }

    char feedback[200];
    cout << "Enter your feedback: ";
    cin.getline(feedback, 200);

    // Save the feedback to feedback.txt
    ofstream feedbackFile("feedback.txt", ios::app); // Open in append mode
    if (feedbackFile.is_open()) {
        // Add timestamp to feedback
        time_t now = time(0);
        char* dt = ctime(&now);
        
        feedbackFile << "Timestamp: " << dt << " Customer Index: " << customerIndex 
                     << " Product: " << orderHistoryProductNames[customerIndex][productChoice - 1]
                     << "   Feedback: " << feedback << endl;
        feedbackFile << "------------------------------------" << endl;
        feedbackFile.close();

        cout << "\n====================================" << endl;
        cout << "       Feedback Submitted!         " << endl;
        cout << "====================================" << endl;
    } else {
        cout << "Error: Could not open feedback file.\n";
    }
}
// Implement View Support Requests (typically for admin/employees)
void viewSupportRequests() 
{
    if (SupportRequestCount == 0) 
    {
        cout << "\n====================================" << endl;
        cout << "    No Support Requests Pending    " << endl;
        cout << "====================================" << endl;
        return;
    }

    cout << "\n====================================" << endl;
    cout << "        Support Requests            " << endl;
    cout << "====================================" << endl;

    for (int i = 0; i < SupportRequestCount; i++) 
    {
        cout << i+1 << ". " << SupportRequests[i] << endl;
    }
}

// Persistent Storage Functions
void loadOrderHistory() 
{
    ifstream file("orderhistory.txt");
    if (file.is_open()) 
    {
        // Initialize order history for all customers
        for (int customer = 0; customer < customerCount; customer++) 
        {
            // Default to zero if file read fails
            orderHistoryCount[customer] = 0;
            
            // Try to read order history for this customer
            int count;
            file >> count;
            
            if (count > 0 && count <= MAX_ORDER_HISTORY) 
            {
                orderHistoryCount[customer] = count;
                
                for (int i = 0; i < count; i++) 
                {
                    // Read product ID
                    file >> orderHistoryProductIDs[customer][i];
                    
                    // Read product name
                    file.ignore(); // Clear newline
                    file.getline(orderHistoryProductNames[customer][i], 50);
                    
                    // Read price
                    file >> orderHistoryPrices[customer][i];
                    
                    // Read date
                    file.ignore(); // Clear newline
                    file.getline(orderHistoryDates[customer][i], 20);
                }
            }
        }
        file.close();
    } else 
    {
        // If file doesn't exist, initialize all order histories to zero
        for (int i = 0; i < customerCount; i++) {
            orderHistoryCount[i] = 0;
        }
    }
}

// Modify saveOrderHistory to handle potential errors
void saveOrderHistory() 
{
    ofstream file("orderhistory.txt");
    if (!file.is_open()) {
        cout << "Error: Unable to open orderhistory.txt for saving.\n";
        return;
    }

    for (int customer = 0; customer < customerCount; customer++) 
    {
        // Write number of order history entries
        file << orderHistoryCount[customer] << '\n';
        
        // Write details for each order history entry
        for (int i = 0; i < orderHistoryCount[customer]; i++) 
        {
            file << orderHistoryProductIDs[customer][i] << '\n' << orderHistoryProductNames[customer][i] << '\n'
                 << orderHistoryPrices[customer][i] << '\n' << orderHistoryDates[customer][i] << '\n';
        }
    }
    file.close();
}

void LoadSupportRequests() 
{
    ifstream file("support.txt");
    if (file.is_open()) 
    {
        file >> SupportRequestCount;
        file.ignore();
        for (int i = 0; i < SupportRequestCount; i++) {
            file.getline(SupportRequests[i], 200);
        }
        file.close();
    }
}

void SaveSupportRequests() 
{
    ofstream file("support.txt");
    file << SupportRequestCount << '\n';
    for (int i = 0; i < SupportRequestCount; i++) 
    {
        file << SupportRequests[i] << '\n';
    }
    file.close();
}