
#include "User.h"

bool User::login(const string& uname, const string& pass) {
    return (username == uname && password == pass);
}
