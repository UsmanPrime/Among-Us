#ifndef CUSTOMER_H
#define CUSTOMER_H
#include"Project.h"

void customerlogin();
void customerloginmenu();
void registration();
void forgot();
void customerMenu(const char* username);
void loadCatalog();
void loadCustomers();
void saveCustomers();
void addItemToCart(int customerIndex);
void manageCart(int customerIndex);
void calculateCartTotal(int customerIndex);
void displayProducts();
void advancedSearch();
void save_Catalog();
void addToWishlist(int customerIndex);
void viewWishlist(int customerIndex);
void removeFromWishlist(int customerIndex);
void loadWishlist();
void saveWishlist();
void viewOrderHistory(int customerIndex);
void submitFeedback(int customerIndex);
void submitSupportRequest(int customerIndex);
void viewSupportRequests();
void loadOrderHistory();
void saveOrderHistory();
void LoadSupportRequests();
void SaveSupportRequests();
void recordOrderHistory(int customerIndex);


#endif 
