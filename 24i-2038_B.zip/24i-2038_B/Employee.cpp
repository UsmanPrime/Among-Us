#include "Employee.h"

using namespace std;

// Global Employee Data
const int MAX_EMPLOYEES = 100;
const int MAX_PRODUCTS = 100;
const int MAX_SUPPORT_REQUESTS = 50;
const int LOW_STOCK_THRESHOLD = 10;

// Support Requests
int supportRequestCount = 0;
char supportRequests[MAX_SUPPORT_REQUESTS][200];

// Global Employee Data
char employeeUsernames[MAX_EMPLOYEES][50];
char employeePasswords[MAX_EMPLOYEES][50];
int employeeCount = 0;
char employeeSalesContributions[MAX_EMPLOYEES][200];
int employeeSalesCount[MAX_EMPLOYEES] = {0};
double employeeSaleRevenue[MAX_EMPLOYEES] = {0.0};

int catalogSize = 0;
int productIds[MAX_PRODUCTS];
char ProductNames[MAX_PRODUCTS][50];
int productprices[MAX_PRODUCTS];
int productStockQuantities[MAX_PRODUCTS];
char productcategories[MAX_PRODUCTS][50];
int productSoldQuantities[MAX_PRODUCTS] = {0};
const int MAX_FEEDBACK = 100;
const int MAX_FEEDBACK_LENGTH = 300;
const int MAX_RESPONSE_LENGTH = 300;
const int MAX_NAME_LENGTH = 50;
char customerNames[MAX_FEEDBACK][MAX_NAME_LENGTH];
char feedbackproductNames[MAX_FEEDBACK][MAX_NAME_LENGTH];
char feedbackMessages[MAX_FEEDBACK][MAX_FEEDBACK_LENGTH];
char employeeResponses[MAX_FEEDBACK][MAX_RESPONSE_LENGTH];
bool isResolved[MAX_FEEDBACK];
int feedbackproductIDs[MAX_FEEDBACK];
char timestamps[MAX_FEEDBACK][MAX_NAME_LENGTH];
int feedbackCount = 0;



// Customer Login (Placeholder)
void login() {
    cout << "\nCustomer login functionality not implemented.\n";
}

// Load Catalog from File
void LoadCatalog() {
    ifstream file("catalog.txt");
    if (!file.is_open()) {
        cout << "\nError loading catalog. Starting with empty catalog.\n";
        return;
    }

    catalogSize = 0;
    while (file >> productIds[catalogSize] 
                >> productprices[catalogSize] 
                >> productStockQuantities[catalogSize] 
                >> productSoldQuantities[catalogSize] 
                && catalogSize < MAX_PRODUCTS) {
        // Use getline to read multi-word product names and categories
        file.ignore(); // Ignore the newline
        file.getline(ProductNames[catalogSize], 50);
        file.getline(productcategories[catalogSize], 50);
        catalogSize++;
    }
    file.close();
}

// Save Catalog to File
void saveCatalog() {
    ofstream file("catalog.txt");
    if (!file.is_open()) {
        cout << "\nError saving catalog.\n";
        return;
    }

    for (int i = 0; i < catalogSize; i++) {
        file << productIds[i] << " " << productprices[i] << " " << productStockQuantities[i] << " " << productSoldQuantities[i] << endl
             << ProductNames[i] << endl << productcategories[i] << endl;
    }
    file.close();
}

// Load Support Requests
void loadSupportRequests() {
    ifstream file("support.txt");
    if (!file.is_open()) {
        cout << "\nNo existing support requests.\n";
        return;
    }

    supportRequestCount = 0;
    while (supportRequestCount < MAX_SUPPORT_REQUESTS && 
           file.getline(supportRequests[supportRequestCount], 200)) {
        supportRequestCount++;
    }
    file.close();
}

// Save Support Requests
void saveSupportRequests() {
    ofstream file("support.txt");
    if (!file.is_open()) {
        cout << "\nError saving support requests.\n";
        return;
    }

    for (int i = 0; i < supportRequestCount; i++) {
        file << supportRequests[i] << endl;
    }
    file.close();
}

// Employee Login
void employeeLogin() {
    char username[50], password[50];

    cout << "\n====================================" << endl;
    cout << "          Employee Login            " << endl;
    cout << "====================================" << endl;

    cout << "\n\tUsername: ";
    cin >> username;
    cout << "\tPassword: ";
    cin >> password;

    // Validate credentials
    for (int i = 0; i < employeeCount; i++) {
        if (strcmp(employeeUsernames[i], username) == 0 && 
            strcmp(employeePasswords[i], password) == 0) {
            cout << "\n====================================" << endl;
            cout << "       Login Successful!            " << endl;
            cout << "====================================" << endl;
            employeeMenu(username);
            return;
        }
    }

    // Invalid credentials
    cout << "\n====================================" << endl;
    cout << "       Invalid Username/Password    " << endl;
    cout << "====================================" << endl;
}

// Employee Menu
void employeeMenu(const char* username) {
    while (true) {
        char choice;
         const bool newvar = true;
        while (newvar)
        {
    cout << "\n\t\t====================================" << endl;
    cout << "\t\t|          EMPLOYEE PANEL          |" << endl;
    cout << "\t\t====================================" << endl;

    // Menu Options
    cout << "\t\t|   1. View Inventory              |\n";
    cout << "\t\t|   2. Add Product                 |\n";
    cout << "\t\t|   3. Update Stock                |\n";
    cout << "\t\t|   4. Generate Reports            |\n";
    cout << "\t\t|   5. Manage Support Requests     |\n";
    cout << "\t\t|   6. Check Low Stock Alerts      |\n";
    cout << "\t\t|   7. Manage Customer Feedback    |\n";
    cout << "\t\t|   8. Logout                      |\n";
    cout << "\t\t====================================" << endl;

    // Prompt for User Input
    cout << "\n\t\tEnter your choice: ";
    cin >> choice;

        cout << "\n\t\t------------------------------------" << endl;
       
             switch (choice) {
        case '1':
            cout << "\t\t| Viewing Inventory...             |\n";
            viewInventory();

            break;
        case '2':
            cout << "\t\t| Redirecting to Add Product...    |\n";
            addProduct();

            break;
        case '3':
            cout << "\t\t| Updating Stock...                |\n";
            updateStock();

            break;
        case '4':
            cout << "\t\t| Generating Reports...            |\n";
            generateReports();

            break;
        case '5':
            cout << "\t\t| Managing Support Requests...     |\n";
            manageSupportRequests();

            break;
        case '6':
            cout << "\t\t| Checking Low Stock Alerts...     |\n";
            checkLowStockAlerts();

            break;
        case '7':
            cout << "\t\t| Managing Customer Feedback...    |\n";
             manageFeedback();

            break;
        case '8':
            cout << "\t\t| Logging out. Goodbye!            |\n";
            exit(0);

            break;
        default:
            cout << "\t\t| Invalid choice. Please try again.|\n";
    }
    cout << "\t\t------------------------------------" << endl;
    }
        }
        
}

// View Inventory
void viewInventory() {
    if (catalogSize == 0) {
        cout << "\nNo products in the catalog.\n";
        return;
    }

    cout << "\n====================================" << endl;
    cout << "           Inventory List           " << endl;
    cout << "====================================" << endl;
    cout << "ID    Name        Price  Stock  Category\n";
    cout << "----------------------------------------\n";

    // Display all products in catalog
    for (int i = 0; i < catalogSize; i++) 
    {
        cout << productIds[i] << "        "
             << left << setw(20) << ProductNames[i] << "        " << right << setw(8) << fixed << setprecision(2) << productprices[i] << "     "
             << right << setw(5) << productStockQuantities[i] << "        " << left << setw(15) << productcategories[i] << endl;
    }

    cout << "------------------------------------------------------------\n";
}


// Add Product
void addProduct() {
    if (catalogSize >= MAX_PRODUCTS) {
        cout << "\n====================================" << endl;
        cout << "         Catalog is Full!           " << endl;
        cout << "====================================" << endl;
        cout << "Cannot add more products.\n";
        return;
    }

    cout << "\n====================================" << endl;
    cout << "          Add New Product           " << endl;
    cout << "====================================" << endl;

    cout << "Enter product name: ";
    cin.ignore();
    cin.getline(ProductNames[catalogSize], 50);

    cout << "Enter product ID: ";
    cin >> productIds[catalogSize];

    cout << "Enter price: ";
    cin >> productprices[catalogSize];

    cout << "Enter stock quantity: ";
    cin >> productStockQuantities[catalogSize];

    cout << "Enter category: ";
    cin.ignore();
    cin.getline(productcategories[catalogSize], 50);

    catalogSize++;
    saveCatalog(); // Save the catalog immediately after adding a product

    cout << "\n------------------------------------" << endl;
    cout << "Product added and saved successfully!" << endl;
    cout << "------------------------------------" << endl;
}


// Load Employees
void loadEmployees() {
    ifstream file("Employees.txt");
    if (!file.is_open()) {
        cout << "\nError loading employees.\n";
        return;
    }

    while (file >> employeeUsernames[employeeCount] >> employeePasswords[employeeCount]) {
        employeeCount++;
    }
    file.close();
}

// Save Employees (Optional)
void saveEmployees() {
    ofstream file("Employees.txt");
    if (!file.is_open()) {
        cout << "\nError saving employees.\n";
        return;
    }

    for (int i = 0; i < employeeCount; i++) {
        file << employeeUsernames[i] << " " << employeePasswords[i] << endl;
    }
    file.close();
}
void updateStock() {
    if (catalogSize == 0) {
        cout << "\nNo products available to update.\n";
        return;
    }

    viewInventory(); // Show available products first

    int id, newStock, updateType;
    cout << "\nEnter Product ID to update: ";
    cin >> id;

    // Find product
    for (int i = 0; i < catalogSize; i++) {
        if (productIds[i] == id) {
            cout << "Current Stock: " << productStockQuantities[i] << endl;
            cout << "Update Type:\n";
            cout << "1. Add Stock\n";
            cout << "2. Subtract Stock\n";
            cout << "3. Set Exact Stock\n";
            cout << "Enter choice: ";
            cin >> updateType;

            switch (updateType) {
                case 1: // Add Stock
                    cout << "Enter Stock to Add: ";
                    cin >> newStock;
                    productStockQuantities[i] += newStock;
                    break;
                case 2: // Subtract Stock
                    cout << "Enter Stock to Subtract: ";
                    cin >> newStock;
                    if (newStock > productStockQuantities[i]) {
                        cout << "Cannot subtract more than current stock.\n";
                        return;
                    }
                    productStockQuantities[i] -= newStock;
                    break;
                case 3: // Set Exact Stock
                    cout << "Enter New Stock Quantity: ";
                    cin >> newStock;
                    productStockQuantities[i] = newStock;
                    break;
                default:
                    cout << "Invalid update type.\n";
                    return;
            }

            cout << "\nStock updated successfully.\n";
            cout << "New Stock: " << productStockQuantities[i] << endl;
            
            // Check and alert if stock is low after update
            if (productStockQuantities[i] <= LOW_STOCK_THRESHOLD) {
                cout << "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
                cout << "WARNING: Low Stock Alert for " << ProductNames[i] << endl;
                cout << "Current Stock: " << productStockQuantities[i] << endl;
                cout << "Recommended Action: Restock Immediately" << endl;
                cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
            }
            
            saveCatalog();
            return;
        }
    }
    cout << "\nProduct ID not found.\n";
}

// Generate Reports (enhanced version)
void generateReports() {
    if (catalogSize == 0) {
        cout << "\nNo products to generate reports for.\n";
        return;
    }

    int reportType;
    cout << "\nReport Types:\n";
    cout << "1. Inventory Overview\n";
    cout << "2. Sales Performance\n";
    cout << "3. Low Stock Alert\n";
    cout << "4. Sales Contribution Report\n"; // New option
    cout << "Enter report type: ";
    cin >> reportType;

    switch (reportType) {
        case 1: { // Inventory Overview
            int totalStock = 0, totalSales = 0;
            double totalRevenue = 0, totalCost = 0;

            cout << "\n====================================" << endl;
            cout << "         Inventory Overview         " << endl;
            cout << "====================================" << endl;
            cout << "ID    Name        Stock  Sales  Revenue  Cost\n";
            cout << "------------------------------------------------\n";

            for (int i = 0; i < catalogSize; i++) {
                double revenue = productprices[i] * productSoldQuantities[i];
                double cost = productprices[i] * productStockQuantities[i];
                
                totalStock += productStockQuantities[i];
                totalSales += productSoldQuantities[i];
                totalRevenue += revenue;
                totalCost += cost;

                cout << productIds[i] << "    " 
                     << ProductNames[i] << "    "
                     << productStockQuantities[i] << "    " 
                     << productSoldQuantities[i] << "    $" 
                     << revenue << "    $" 
                     << cost << endl;
            }

            cout << "\nTotal Stock: " << totalStock << endl;
            cout << "Total Sales: " << totalSales << endl;
            cout << "Total Revenue: $" << totalRevenue << endl;
            cout << "Total Inventory Cost: $" << totalCost << endl;
            break;
        }
        case 2: { // Sales Performance
            cout << "\n====================================" << endl;
            cout << "         Sales Performance          " << endl;
            cout << "====================================" << endl;
            
            // Sort products by sales volume
            for (int i = 0; i < catalogSize - 1; i++) {
                for (int j = 0; j < catalogSize - i - 1; j++) {
                    if (productSoldQuantities[j] < productSoldQuantities[j + 1]) {
                        // Swap all product details
                        swap(productIds[j], productIds[j + 1]);
                        swap(ProductNames[j], ProductNames[j + 1]);
                        swap(productprices[j], productprices[j + 1]);
                        swap(productStockQuantities[j], productStockQuantities[j + 1]);
                        swap(productSoldQuantities[j], productSoldQuantities[j + 1]);
                    }
                }
            }

            cout << "Top Selling Products:\n";
            cout << "ID    Name        Sales  Revenue\n";
            cout << "--------------------------------\n";
            for (int i = 0; i < min(5, catalogSize); i++) {
                double revenue = productprices[i] * productSoldQuantities[i];
                cout << productIds[i] << "    " 
                     << ProductNames[i] << "    "
                     << productSoldQuantities[i] << "    $" 
                     << revenue << endl;
            }
            break;
        }
        case 3: { // Low Stock Alert
            cout << "\n====================================" << endl;
            cout << "           Low Stock Alert          " << endl;
            cout << "====================================" << endl;
            
            int lowStockThreshold;
            cout << "Enter low stock threshold: ";
            cin >> lowStockThreshold;

            cout << "Products Below Threshold:\n";
            cout << "ID    Name        Current Stock\n";
            cout << "--------------------------------\n";

            bool lowStockFound = false;
            for (int i = 0; i < catalogSize; i++) {
                if (productStockQuantities[i] <= lowStockThreshold) {
                    cout << productIds[i] << "    " 
                         << ProductNames[i] << "    "
                         << productStockQuantities[i] << endl;
                    lowStockFound = true;
                }
            }

            if (!lowStockFound) {
                cout << "No products below the threshold.\n";
            }
            break;
        }
        case 4: { // Sales Contribution Report
            generateSalesReport();
            break;
        }
        default:
            cout << "Invalid report type.\n";
    }
}

void checkLowStockAlerts() {
    cout << "\n====================================" << endl;
    cout << "        Low Stock Alerts            " << endl;
    cout << "====================================" << endl;

    bool lowStockFound = false;
    for (int i = 0; i < catalogSize; i++) {
        if (productStockQuantities[i] <= LOW_STOCK_THRESHOLD) {
            cout << "ALERT: Low Stock for " << ProductNames[i] << endl;
            cout << "  Product ID: " << productIds[i] << endl;
            cout << "  Current Stock: " << productStockQuantities[i] << endl;
            cout << "  Recommended Action: Restock Immediately" << endl;
            cout << "------------------------------------" << endl;
            lowStockFound = true;
        }
    }

    if (!lowStockFound) {
        cout << "No products require restocking." << endl;
    }
}
// Manage Support Requests (enhanced version)
void manageSupportRequests() {
    if (supportRequestCount == 0) {
        cout << "\nNo pending support requests.\n";
        return;
    }

    int action;
    cout << "\nSupport Request Actions:\n";
    cout << "1. View Requests\n";
    cout << "2. Resolve Individual Request\n";
    cout << "3. Resolve All Requests\n";
    cout << "Enter choice: ";
    cin >> action;

    switch (action) {
        case 1: { // View Requests
            cout << "\n====================================" << endl;
            cout << "        Support Request List         " << endl;
            cout << "====================================" << endl;

            for (int i = 0; i < supportRequestCount; i++) {
                cout << i + 1 << ". " << supportRequests[i] << endl;
            }
            break;
        }
        case 2: { // Resolve Individual Request
            int requestIndex;
            cout << "Enter request number to resolve: ";
            cin >> requestIndex;

            if (requestIndex < 1 || requestIndex > supportRequestCount) {
                cout << "Invalid request number.\n";
                return;
            }

            // Shift remaining requests
            for (int i = requestIndex - 1; i < supportRequestCount - 1; i++) {
                strcpy(supportRequests[i], supportRequests[i + 1]);
            }
            supportRequestCount--;

            cout << "Request resolved successfully.\n";
            saveSupportRequests();
            break;
        }
        case 3: { // Resolve All Requests
            cout << "Mark all requests as resolved? (y/n): ";
            char choice;
            cin >> choice;

            if (choice == 'y' || choice == 'Y') {
                supportRequestCount = 0;
                cout << "\nAll requests resolved.\n";
                saveSupportRequests();
            }
            break;
        }
        default:
            cout << "Invalid choice.\n";
    }
}

// Modify the generateSalesReport() function to remove accumulate()
void generateSalesReport() {
    ofstream salesReport("SalesReport.txt");
    if (!salesReport.is_open()) {
        cout << "Error creating sales report file.\n";
        return;
    }

    cout << "\n====================================" << endl;
    cout << "       Sales Contribution Report    " << endl;
    cout << "====================================" << endl;

    salesReport << "Sales Contribution Report\n";
    salesReport << "========================\n\n";

    // Manual calculation of total company sales
    double totalCompanySales = 0.0;
    for (int i = 0; i < employeeCount; i++) {
        totalCompanySales += employeeSaleRevenue[i];
    }

    for (int i = 0; i < employeeCount; i++) {
        if (employeeSalesCount[i] > 0) {
            // Manual percentage calculation
            double contributionPercentage = totalCompanySales > 0 
                ? (employeeSaleRevenue[i] / totalCompanySales) * 100.0 
                : 0.0;
            
            cout << "Employee: " << employeeUsernames[i] << endl;
            cout << "Total Sales: " << employeeSalesCount[i] << endl;
            cout << "Total Revenue: $" << employeeSaleRevenue[i] << endl;
            
            // Manual precision formatting
            int wholePart = static_cast<int>(contributionPercentage);
            int fractionalPart = static_cast<int>((contributionPercentage - wholePart) * 100);
            
            cout << "Contribution: " 
                 << wholePart << "." 
                 << (fractionalPart < 10 ? "0" : "") 
                 << fractionalPart << "%" << endl;
            cout << "------------------------------------" << endl;

            salesReport << "Employee: " << employeeUsernames[i] << endl;
            salesReport << "Total Sales: " << employeeSalesCount[i] << endl;
            salesReport << "Total Revenue: $" << employeeSaleRevenue[i] << endl;
            salesReport << "Contribution: " 
                        << wholePart << "." 
                        << (fractionalPart < 10 ? "0" : "") 
                        << fractionalPart << "%" << endl;
            salesReport << "------------------------------------" << endl;
        }
    }

    cout << "Total Company Sales: $" << totalCompanySales << endl;
    salesReport << "Total Company Sales: $" << totalCompanySales << endl;

    salesReport.close();
    cout << "\nSales report saved to SalesReport.txt" << endl;
}
// New function to record sales contribution
void recordSalesContribution(const char* username, double saleAmount) {
    // Find the employee in the employee list
    for (int i = 0; i < employeeCount; i++) {
        if (strcmp(employeeUsernames[i], username) == 0) {
            employeeSalesCount[i]++;
            employeeSaleRevenue[i] += saleAmount;
            
            // Optional: Log the specific sale
            char saleEntry[200];
            snprintf(saleEntry, sizeof(saleEntry), "Sale of $%.2f recorded", saleAmount);
            strncpy(employeeSalesContributions[i], saleEntry, sizeof(employeeSalesContributions[i]) - 1);
            
            break;
        }
    }
}

void viewFeedbackDetails(int index) {
    cout << "\n====================================" << endl;
    cout << "        Feedback Details            " << endl;
    cout << "====================================" << endl;
    
    cout << "Customer: " << customerNames[index] << endl;
    cout << "Product: " << ProductNames[index] << endl;
    cout << "Product ID: " << feedbackproductIDs[index] << endl;
    cout << "Timestamp: " << timestamps[index];
    cout << "Feedback: " << feedbackMessages[index] << endl;
    cout << "Status: " << (isResolved[index] ? "Resolved" : "Pending") << endl;
    cout << "Employee Response: " << employeeResponses[index] << endl;
}

// Manage Feedback (for Employees)
void manageFeedback() {
    if (feedbackCount == 0) {
        cout << "\nNo pending feedback.\n";
        return;
    }

    int action;
    cout << "\nFeedback Management:\n";
    cout << "1. View All Feedback\n";
    cout << "2. Respond to Specific Feedback\n";
    cout << "3. Mark Feedback as Resolved\n";
    cout << "Enter choice: ";
    cin >> action;

    switch (action) {
        case 1: { // View All Feedback
            cout << "\n====================================" << endl;
            cout << "        Feedback List              " << endl;
            cout << "====================================" << endl;
            
            for (int i = 0; i < feedbackCount; i++) {
                cout << i + 1 << ". Product: " << ProductNames[i] 
                     << " - Status: " << (isResolved[i] ? "Resolved" : "Pending") 
                     << endl;
            }
            break;
        }
        case 2: { // Respond to Feedback
            int feedbackIndex;
            cout << "Enter feedback number to respond: ";
            cin >> feedbackIndex;

            if (feedbackIndex < 1 || feedbackIndex > feedbackCount) {
                cout << "Invalid feedback number.\n";
                return;
            }

            viewFeedbackDetails(feedbackIndex - 1);

            cout << "\nEnter your response: ";
            cin.ignore();
            cin.getline(employeeResponses[feedbackIndex - 1], MAX_RESPONSE_LENGTH);

            saveFeedbacks();
            cout << "Response recorded successfully.\n";
            break;
        }
        case 3: { // Mark as Resolved
            int feedbackIndex;
            cout << "Enter feedback number to mark as resolved: ";
            cin >> feedbackIndex;

            if (feedbackIndex < 1 || feedbackIndex > feedbackCount) {
                cout << "Invalid feedback number.\n";
                return;
            }

            isResolved[feedbackIndex - 1] = true;
            saveFeedbacks();
            cout << "Feedback marked as resolved.\n";
            break;
        }
        default:
            cout << "Invalid choice.\n";
    }
}
void loadFeedbacks() {
    ifstream file("feedback.txt");
    if (!file.is_open()) {
        cout << "\nNo existing feedback records.\n";
        return;
    }

    feedbackCount = 0;
    while (feedbackCount < MAX_FEEDBACK && 
           file.getline(customerNames[feedbackCount], MAX_NAME_LENGTH) &&
           file.getline(ProductNames[feedbackCount], MAX_NAME_LENGTH) &&
           file.getline(feedbackMessages[feedbackCount], MAX_FEEDBACK_LENGTH) &&
           file.getline(employeeResponses[feedbackCount], MAX_RESPONSE_LENGTH)) {
        
        file >> isResolved[feedbackCount];
        file >> feedbackproductIDs[feedbackCount];
        file.ignore(); // Clear newline
        file.getline(timestamps[feedbackCount], MAX_NAME_LENGTH);
        
        feedbackCount++;
    }
    file.close();
}
void saveFeedbacks() {
    ofstream file("feedback.txt");
    if (!file.is_open()) {
        cout << "\nError saving feedback records.\n";
        return;
    }

    for (int i = 0; i < feedbackCount; i++) {
        file << customerNames[i] << endl
             << ProductNames[i] << endl
             << feedbackMessages[i] << endl
             << employeeResponses[i] << endl
             << isResolved[i] << endl
             << feedbackproductIDs[i] << endl
             << timestamps[i] << endl;
    }
    file.close();
}

// Main Function
void employeeLoginmenu() {
    LoadCatalog();
    loadSupportRequests();
    loadEmployees();
    //loadEmployeeSalesContributions();
    loadFeedbacks();

    char choice;
    while (true) {
        cout << "\n====================================" << endl;
        cout << "          SecureShop System         " << endl;
        cout << "====================================" << endl;

        cout << "\t1. Customer Login\n";
        cout << "\t2. Employee Login\n";
        cout << "\t3. Exit\n";

        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case '1': {
                login(); // Existing customer login
                break;
            }
            case '2': {
                employeeLogin();
                break;
            }
            case '3': {
                cout << "\nExiting...\n";
                saveCatalog();
                saveSupportRequests();
                saveEmployees();
                
                // Create a block to allow local variable initialization
                {
                    ofstream salesContributionFile("EmployeeSales.txt");
                    if (salesContributionFile.is_open()) {
                        for (int i = 0; i < employeeCount; i++) {
                            salesContributionFile << employeeUsernames[i] << " "
                                                 << employeeSalesCount[i] << " "
                                                 << employeeSaleRevenue[i] << endl;
                        }
                        salesContributionFile.close();
                    }
                }
                
            }
            exit(0);
            break;
            default:
                cout << "\nInvalid choice. Please try again.\n";
                break;
        }
    }
    
   
}
