#ifndef PROJECT_H
#define PROJECT_H

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
#include <cstdlib>
#include <limits>
#include <ctime>

#include"Admin.h"
#include"Customer.h"
#include"Employee.h"


#endif